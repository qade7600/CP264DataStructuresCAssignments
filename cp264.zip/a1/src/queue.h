/*
 * queue.h
 *
 *  Created on: 2019 M10 17
 *      Author: ranaqaderi
 */

#ifndef QUEUE_H_
#define QUEUE_H_

typedef struct node {
int id;
int totaltime;//amount it needs to run
int currenttime;//amount it is currently at
int readytime;
int blockedtime; //total time blocked
int starttime;
//exchange times
int blocked; //per segment
int remaining;
struct node *next;
} QNODE;


void enqueue(QNODE **frontp, QNODE **rearp, int id, int run, int current_run, int ready, int blocked, int start, int bl, int r);
int dequeue(QNODE **frontp, QNODE **rearp);
int peek_id(QNODE *front);
int peek_start_time(QNODE *front);
int peek_current_runtime(QNODE *front);

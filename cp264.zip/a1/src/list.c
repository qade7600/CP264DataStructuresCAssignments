/*
 * list.c
 *
 *  Created on: 2019 M10 17
 *      Author: ranaqaderi
 */

#include "list.h"

int display_front(LNODE *start) {
int value = 0;
if(start != NULL){
value = start->process_id;
}
return value;
}

void insert(LNODE **startp, int id, int run, int rtime, int ready, int blocked, int start, int bl, int r) {

LNODE *p = (LNODE*) malloc(sizeof(LNODE));
//process number
p->process_id = id;
p->total_runtime = run;
p->current_runtime = rtime;
p->total_readytime = ready;
p->total_blockedtime = blocked;
p->start_time = start;
p->blocked_time = bl;
p->remaining = r;
p->next = NULL;

LNODE *prev = NULL;
LNODE *ptr = *startp;

while(ptr != NULL){
if(ptr->remaining > p->remaining){ //RELOOK AT THIS
break;
}
prev = ptr;
ptr = ptr->next;
}
if (prev == NULL){
*startp = p;
p->next = ptr;
}else{
prev->next = p;
p->next = ptr;
}






void delete(LNODE **startp) {
LNODE *ptr = *startp;
if(*startp == NULL){
return;
}
if(ptr->next == NULL){
*startp = NULL;
free(*startp);
}else{
*startp = (*startp)->next;
free(ptr);
}


/*
 * list.h
 *
 *  Created on: 2019 M10 17
 *      Author: ranaqaderi
 */

#ifndef LINKED_LIST_H_
#define LINKED_LIST_H_


#include <stdio.h>
#include <stdlib.h>


typedef struct node1 {
int id;
int totaltime;
int current_runtime;
int total_readytime;
int total_blockedtime;
int start_time;
int blocked_time;
int remaining;
struct node1 *next;
} LNODE;



int display_front(LNODE *start);
void insert(LNODE **startp, int id, int run, int rtime, int ready, int blocked, int start, int bl, int r);
void delete(LNODE **startp);




#endif /* LINKED_LIST_H_ */

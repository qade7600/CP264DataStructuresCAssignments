/*
Do not edit the contents of this file
*/
#ifndef DISPATCHER_H_
#define DISPATCHER_H_

/*
Do not edit the contents of this file
*/


void dispatcher(FILE *fd, int harddrive);





#endif /* DISPATCHER_H_ */

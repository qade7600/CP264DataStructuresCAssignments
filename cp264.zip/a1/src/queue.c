/*
 * queue.c
 *
 *  Created on: 2019 M10 17
 *      Author: ranaqaderi
 */

#include<string.h>
#include<stddef.h>
#include<stdio.h>



void enqueue(QNODE **frontp, QNODE **rearp, int id, int run, int current_run, int ready, int blocked, int start, int bl, int r)
{
QNODE *new_node = (QNODE*) malloc(sizeof(QNODE));


//process number
new_node->id = id;
//time in current process
new_node->totaltime = run;
//amount of time left for current process
new_node->currenttime = current_run;
//ready queue
new_node->readytime = ready;
//blocked queue
new_node->blockedtime = blocked;
//time node needs to go to ready queue
new_node->starttime = start;
//!!!!!
//current blocked time
new_node->blocked = bl;
new_node->remaining = r;



if (*frontp == NULL && *rearp == NULL) {
*frontp = new_node;
*rearp = *frontp;
new_node->next = NULL;
} else {
(*rearp)->next = new_node;
new_node->next = NULL;
*rearp = new_node;
}
}


int dequeue(QNODE **frontp, QNODE **rearp)
{
QNODE *temp;
int result = 0;
if(*frontp != NULL){
result = (*frontp)->process_id;
if(*frontp == *rearp){
*frontp = NULL;
*rearp = NULL;
}else{
temp = *frontp;
*frontp = (*frontp)->next;
free(temp);
}
}
return result;
}

int peek(QNODE *front)
{
int value = 0;
if (front != NULL) {
value = front->process_id;
}
return value;
}

int peek_start_time(QNODE *front){
int value = 0;
if (front != NULL) {
value = front->start_time;
}
return value;
}
int peek_current_runtime(QNODE *front){
int value = 0;
if (front != NULL) {
value = front->current_runtime;
}
return value;
}

/*
-------------------------------------
File:    qade7600_l02t1
Project: qade7600_l02t1
 Compute circumference, area and hypotenuse
-------------------------------------
Author:  Rana Qaderi
ID:      170317600
Email:   qade7600@wlu.ca
Version: 2019-01-20
-------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <functions.h>

int main() {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	double r;
	double s1;
	double s2;

	printf("Enter Radius: \n");
	scanf("%lf", %r);

	printf("Enter Side 1: \n");
	scanf("%lf", %s1);

	printf("Enter Side 2: \n");
	scanf("%lf", %s2);

	printf("The circle cirfumference is: %.6f\n", cirfumference(r));
	printf("The circle area is : %.6f\n", area(r));
	printf("The triangle hypoteuse is: %.6f\n", hypotenuse(s1, s2));

	return 0;
}

/*
 ============================================================================
 Project: qade7600_l03t1.c
 File:    l03t1.c
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[]) {
	setbuf(stdout, NULL);
	printf("Index     Value\n");

	int i, n = argc - 1;
	int a[n];

		for (i = 0; i <= n; i++) {
			a[i] = atoi(args[i+1]);
			printf("%d         %d\n", i, a[i]);
		}

	return EXIT_SUCCESS;
}

/*
 ============================================================================
 Project: cp264a7q1
 File:    cp264a7q1
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */


#include "avl.h"

int main(int argc, char* args[])
{
	int n = 8;
	if (argc >1)  {
		n = atoi(args[1]);
	}

	TNODE *root = NULL, *np;

	int i;
	char name[20];
	for (i = 0; i < n; i++) {
		itoa(i, name, 10);  //itoa(int value, char *string, int radix)
		insert(&root, name, i+0.0);
	}

	display_tree(root, 0);
	printf("is_val:%d\n", is_avl(root));
	display_inorder(root);

	for (i = 0; i < n; i++) {
		if (i % 2 == 0) {
			itoa(i, name, 10);
			delete(&root, name);
		}
	}
	display_tree(root, 0);
	printf("is_val:%d\n", is_avl(root));
    display_inorder(root);
	clean_tree(&root);
	return 0;
}

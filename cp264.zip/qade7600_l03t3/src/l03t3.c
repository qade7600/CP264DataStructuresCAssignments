/*
 ============================================================================
 Project: qade7600_l03t3.c
 File:    l03t3.c
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#define ARRAY_SIZE 120

int main(void) {
	setbuf(stdout, NULL);
	FILE *fp = NULL;
	char *filename = "data.csv\0";
	char comma[] = ",\0";
	char line[ARRAY_SIZE];
	int i = 0, j = 0;
	char str1[10], str2[10], date[20];
	int id;
	float amount = 0, total = 0.0;

	fp = fopen(filename, "r");
	if (fp == NULL) {
		printf("\nCannot open file '%s'.\n", filename);
	} else {
		while (fgets(line, ARRAY_SIZE, fp) != NULL) {
			id = atoi(strtok(line, comma));
			amount = atof(strtok(NULL, comma));
			total += amount;
			strncpy(date, strtok(NULL, comma), 20);
			strncpy(str1, strtok(NULL, comma), 10);
			strncpy(str2, strtok(NULL, comma), 10);
			printf("%d %.2f %s %s %s\n", id, amount, date, str1, str2);
		}
		printf("\n");
		printf("\nThe total of the balances is: $%.2f", total);
		fclose(fp);
	}
	return 0;

}

/*
 ============================================================================
 Project: cp264a7q1
 File:    cp264a7q1
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

/* driver program to test above functions */

#include "tree_avl.h"

int main()
{
  tnode *root = NULL;

  /* Constructing tree given in the above figure */
  root = insert(root, 9);
  root = insert(root, 5);
  root = insert(root, 10);
  root = insert(root, 0);
  root = insert(root, 6);
  root = insert(root, 11);
  root = insert(root, -1);
  root = insert(root, 1);
  root = insert(root, 2);

  /* The constructed AVL Tree would be
             9
           /  \
          1    10
        /  \     \
       0    5     11
      /    /  \
     -1   2    6
    */

  print_tree(root, 0);
  printf("\nPreorder traversal of the constructed AVL tree is \n");
  print_preorder(root);

  root = delete(root, 10);

  /* The AVL Tree after deletion of 10
            1
           /  \
          0    9
        /     /  \
       -1    5    11
           /  \
          2    6
    */

  printf("\nafter deletion of 10\n");
  print_tree(root, 0);
  printf("\nPreorder traversal after deletion of 10 \n");
  print_preorder(root);

  return 0;
}

#include "matrix.h"

//---------------------------------------------------------
void magic_square(int *m, int n) {
	/* assign 3X3 matrix to following values
	 8     1     6
	 3     5     7
	 4     9     2
	 */
	int values[9] = { 8, 1, 6, 3, 5, 7, 4, 9, 2 };
	int i, len = n * n, *p = values;
	for (i = 0; i < len; i++)
		*m++ = *p++;
}

//---------------------------------------------------------
void display_matrix(int *m, int n) {
	int *p = m, i, j;
	for (i = 0; i < n; i++) {
		printf("\n");
		for (j = 0; j < n; j++)
			printf("%4d", *p++);
	}
	printf("\n");
}

//---------------------------------------------------------
int is_magic_square(int *m, int n) {
// your implementation
	int rSum = 0, cSum = 0, ldiSum = 0, sum = 0, isSquare = 1;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (i == j) {  //calculates major diagonal
				sum += *(m + (i * n) + j);
			}
			if (i + j == n - 1) { //calculates minor diagonal
				ldiSum += *(m + (i * n) + j);
			}
		}
	}
	for (int i = 0; i < n; i++) {
		rSum = 0; //resets values for row sum and column sum for next iteration in inner loop
		cSum = 0;
		for (int j = 0; j < n; j++) {
			rSum += *(m + (i * n) + j); //calculates row sum
			cSum += *(m + (j * n) + i); //calculates count sum
		}
		if (ldiSum != sum) {
			isSquare = 0;
		}
		if (sum != cSum && sum != rSum) { //compares the rows and sum after the completion of the inner loop each time
			isSquare = 0;
		}
	}
	return isSquare;
}

//---------------------------------------------------------
void transpose_matrix(int *m1, int *m2, int n) {
// your implementation
	int i = 0, j = 0, t = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			t = *(m1 + (i * n) + j);
			*(m1 + (i * n) + j) = *(m2 + (j * n) + i);
			*(m2 + (j * n) + i) = t;
		}
	}
}
//---------------------------------------------------------
void multiply_matrix(int *m1, int *m2, int *m3, int n) {

	int i = 0, j = 0, k = 0, sum = 0;
	magic_square(m1, n);
	transpose_matrix(m1, m2, n);

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			sum = 0;
			for (k = 0; k < n; k++) {
				sum += *(m1 + (i * n + k)) * *(m2 + (k * n + j));
			}
			*(m3 + (i * n + j)) = sum;
		}
	}
}

/*
 ============================================================================
 Project: qade7600_l06t3
 File:    l06t3
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */


#include "lqueue.h"

int main() {
  int i, val;
  queue myq = {0};
  queue myq2 = {0};
  myq.front = NULL;
  myq.rear = NULL;
  for (i=1; i<=5; i++) {
       printf("Enqueue value:%d\n", i);
       enqueue(&myq, i);
    }

  myq2.front = NULL;
  myq2.rear = NULL;
   for (i=1; i<=5; i++) {
        printf("Enqueue value:%d\n", i);
        enqueue(&myq2, i);
     }
    printf("\nDisplay all:\n");
    display(myq);

    printf("\nmove front to rear: \n");
    display(myq2);
    printf("\n");
    display(myq);
    move_front_to_rear(&myq, &myq2);
    move_front_to_rear(&myq, &myq2);
    move_front_to_rear(&myq, &myq2);
    printf("\nmyq2\n");
    display(myq2);
    printf("\nmyq\n");
    display(myq);

  return 0;
}

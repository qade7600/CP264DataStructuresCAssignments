/*
 ============================================================================
 Project: cp264a6q2
 File:    a6q2
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include "stack.h"

int main(int argc, char* args[]) {
  SNODE *top = NULL;
  int i=0;
  for (i=1; i<=12; i++) {
    push(&top, i);
  }

  printf("%d ", peek(top));
  pop(&top);
  printf("%d ", peek(top));
  printf("\n");

  while (top != NULL) {
    printf("%d ", peek(top));
    pop(&top);
  }

  for (i=1; i<=12; i++) {
    push(&top, i);
  }
  clean(&top);
  while (top != NULL) {
    printf("%d ", peek(top));
    pop(&top);
  }

  return 0;
}

#include "stack.h"

void push(SNODE **topp, int value) {
// your code
	SNODE *ptr = (SNODE*) malloc(sizeof(SNODE));
	ptr->data = value;
	if (*topp == NULL) {
		ptr->next = NULL;
		*topp = ptr;
	} else {
		ptr->next = *topp;
		*topp = ptr;
	}
}

void pop(SNODE **topp) {
// your code
	if (*topp == NULL)
		printf("\nUNDERFLOW");
	else {
		SNODE *temp = *topp;
		*topp = temp->next;
		free(temp);
	}
}

int peek(SNODE *top) {
// your code
	if (top == NULL) {
		printf("\nEMPTY");
		return -1;
	} else
		return top->data;
}

void clean(SNODE **topp) {
// your code
	SNODE *ptr = *topp, *temp;
		while (ptr != NULL) {
			temp = ptr;
			ptr = ptr->next;
			free(temp);
		}
		*topp = NULL;
}

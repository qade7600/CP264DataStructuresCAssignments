/*
 ============================================================================
 Project: qade7600_l04t2
 File:    l04t2
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include <stdio.h>


int main() {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

//	char buf[50];
	float total = 0.0;
	char id[20];
	float balance = 0.0;
	char date[20];
	char name[20];
	char last[20];

	FILE *fp = fopen("data.txt", "r");
	if (fp == NULL){perror("Error opening file"); return 0;}
	else{
		while(fscanf(fp, "%s %f %s %s %s\n", id, &balance, date, name, last)!= EOF){
				 printf("%s %f %s %s %s\n", id, balance, date, name, last);
				 total += balance;


		 }
		printf("\n");
		printf("The total of the balance is: %.2f", total);

	}
	 fclose(fp);
	 return 0;

}

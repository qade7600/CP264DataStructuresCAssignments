/*
 ============================================================================
 Project: qade7600_l03t2.c
 File:    l03t2.c
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */



#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
int i, total = 0;
int a[argc - 1];
// read command line arguments convert them to floating numbers atof(args[i+1]);
for (i = 0; i < argc - 1; i++) {
a[i] = atoi(argv[i + 1]);
}
for (i = 0; i < argc - 1; i++) {
total += a[i];
}
printf("Total Using Index i: %d\n", total);
printf("\n");

int *x = a;  // pointer to first element of array
int total2 = 0;
while (x < a + argc - 1) {
int b = *(x++);
total2 += b;
//printf("%d\n", total2);
}
printf("Total Using Pointers: %d\n", total);




return EXIT_SUCCESS;
}


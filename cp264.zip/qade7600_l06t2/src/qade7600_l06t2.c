/*
 ============================================================================
 Project: qade7600_l06t2
 File:    l06t2
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include "lstack.h"

int main() {
  snode *top = NULL;
  printf("push:\n");
  push(&top, 1);
  push(&top, 2);
  push(&top, 3);
  push(&top, 4);
  printf("display:\n");
  display_stack(top);
  printf("\npeek:%d\n", peek(top));
  printf("pop\n");
  pop(&top);
  printf("display:\n");
  display_stack(top);

  snode *snp = pop1(&top);
  printf("pop1 %d\n", snp->data);
  free(snp);
  printf("display:\n");
  display_stack(top);

  pop2(&top, &snp);
  printf("pop2 %d\n", snp->data);
  free(snp);
  printf("display:\n");
  display_stack(top);

  return 0;
}

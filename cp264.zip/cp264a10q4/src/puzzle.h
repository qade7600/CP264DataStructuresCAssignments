/*
 * puzzle.h
 *
 *  Created on: 2019 M04 3
 *      Author: ranaqaderi
 */

#ifndef PUZZLE_H_
#define PUZZLE_H_

#include <stdio.h>
#include <stdlib.h>

typedef struct state{
	int a[9];
	struct node *parents; //used for back tracking
} state;

typedef struct node{
	state *sp;
	struct node *next;
}node;


void display_state(state *s);
int is_valid(state *s);
int count_inverse(state *s);
int is_match(state *s, state *s1);
int is_contain(node *start, state *s);
int breadth_first_search(state s, state goal);

#endif /* PUZZLE_H_ */

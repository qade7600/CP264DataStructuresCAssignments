/*
 * puzzle.c
 *
 *  Created on: 2019 M04 3
 *      Author: ranaqaderi
 */

#include "puzzle.h"

void display_state(state *s){
	int i, j;
	int *p = s->a;
	for (i = 0; i < 3; i ++){
		for(j = 0;j < 3; j++)printf("%d", *p++);
		printf("\n");
		}
	printf("\n");
}

int is_valid(state *s){
	int r[9] = {0};
	int *p = s->a;
	int i = 0;
	for (i = 0; i < 9; i++) r[*p++]++;
	for (i = 0; i < 9; i++){
		if (r[i] != 1) return 0;
	}
	return 1;
}


int count_inverse(state *s){
	int counter = 0;
	int i, j;
	int *p = s->a;
	int *p1;
	for (i = 0; i< 8; i++) {
		p1 = p + 1;
		for (j = i + 1; j < 9; j++) {
			if (*p && *p1 && *p > *p1)
				counter++;
			p1++;
		}
		p++;
	}
	return counter;
}


int is_match(state *s, state *s1){
	int r = 1;
	int i;
	int *p = s->a, *p1 = s1->a;
	for (i = 0; i < 9; i++){
		if (*p++ != *p1++){r = 0; break;}
	}
	return r;
}


int is_contain(node *start, state *s){
	node *p = start;
	if (p == NULL) return 0;
	else {
		while (p!= NULL) {
			if (is_match(p->sp, s)) return 1;
			p = p->next;
		}
	}
	return 0;

}


int breadth_first_search(state s, state goal){
	if (is_match(&s, &goal) == 1) return 1;
	else{
		node *visited = NULL;
		node *front = NULL;
		node *rear = NULL;
		state *sp = NULL;
		state *wp = NULL;
		int i, j, h;
		int *p;

		insert_beg(&visited, &s);
		insert_end(&front, &rear, &s);

		while (front != NULL) {
			sp = front->sp;
			delete_beg2(&front, &rear);

			p = sp->a;
			for (h = 0; h < 9; h++){
				if (*p++ == 0) break;
			}
			i = h / 3;
			j = h % 3;

			//creates neighbours; move up, right, down, left, for each neighbour
			//if not visited, mark visited and push to stack
		}
	}
	return 0;
}


/*
 ============================================================================
 Project:  lab01_task02_qade7600
 File:     main.c
  -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[]) {
    setbuf(stdout, NULL);
    int i = 0;
    int total = 0;

    // Convert the arguments to int and total them.
    for (i = 1; i < argc; i++) {
        printf("%d\n", atoi(args[i]));
        total += atoi(args[i]);
    }
    printf("Total: %d", total);
    return (0);
}

//use double not float

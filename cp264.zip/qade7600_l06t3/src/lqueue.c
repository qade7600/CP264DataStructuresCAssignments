#include "lqueue.h"

void enqueue(queue *q, int val) {
	qnode *ptr;
	ptr = (qnode*) malloc(sizeof(qnode));
	ptr->data = val;
	if (q->front == NULL) {
		q->front = ptr;
		q->rear = ptr;
		q->front->next = q->rear->next = NULL;
	} else {
		q->rear->next = ptr;
		q->rear = ptr;
		q->rear->next = NULL;
	}
}

int dequeue(queue *q) {
	int val = -1;
	if (q->front == NULL)
		printf("\nUNDERFLOW");
	else {
		qnode *ptr = q->front;
		val = ptr->data;
		q->front = ptr->next;
		free(ptr);
	}
	return val;
}

qnode *dequeue1(queue *q) {
	qnode *ptr = NULL;
	if (q->front) {
		ptr = q->front;
		if (q->front == q->rear) {
			q->front = NULL;
			q->rear = NULL;
		} else {
			q->front = ptr->next;
		}
	}
	return ptr;
}

void dequeue2(queue *q, qnode **npp) {
	qnode *ptr = NULL;
	if (q->front) {
		ptr = q->front;
		if (q->front == q->rear) {
			q->front = NULL;
			q->rear = NULL;
		} else {
			q->front = ptr->next;
		}
	}
	*npp = ptr;
}

int peek(queue q) {
	if (q.front == NULL) {
		printf("\nQUEUE IS EMPTY");
		return -1;
	} else
		return q.front->data;
}

void display(queue p) {
	qnode *ptr = p.front;
	if (ptr == NULL)
		printf("\n QUEUE IS EMPTY");
	else {
		while (ptr != p.rear) {
			printf("%d\t", ptr->data);
			ptr = ptr->next;
		}
		printf("%d\t", ptr->data);
	}

}

void clean(queue *q) {
	if (q->front != NULL) {
		qnode *temp, *ptr = q->front;

		while (ptr != NULL) {
			temp = ptr;
			ptr = ptr->next;
			free(temp);
		}
		q->front = NULL;
		q->rear = NULL;
	}
}

void move_front_to_rear(queue *target, queue *source) {
	if (source->front == NULL) {
		printf("empty");
	} else {
		qnode *ptr = source->front;
		target->rear->next = ptr;
		target->rear = target->rear->next;
		source->front = ptr->next;
	}
}


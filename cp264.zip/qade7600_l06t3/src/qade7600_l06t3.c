/*
 ============================================================================
 Project: qade7600_l06t3
 File:    l06t3
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */


#include "lqueue.h"

int main() {
  int i, val;
  queue myq = {0};
  myq.front = NULL;
  myq.rear = NULL;
  for (i=1; i<=5; i++) {
     printf("Enqueue value:%d\n", i);
     enqueue(&myq, i);
  }
  printf("\nDisplay all:\n");
  display(myq);

  printf("\nDequeue value: %d\n", dequeue(&myq));

  qnode *qnp = dequeue1(&myq);
  printf("\nDequeue1: %d\n", qnp->data);
  free(qnp);


  dequeue2(&myq, &qnp);
  printf("\nDequeue2: %d\n", qnp->data);
  free(qnp);

  printf("\nDisplay all:\n");
  display(myq);
  clean(&myq);
  return 0;
}

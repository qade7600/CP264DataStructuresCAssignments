/*
 ============================================================================
 Project:  lab01_task01_qade7600
 File:     main.c
  -------------------------------------------------------
 Author:  Rana
 Version: 2019-01-11
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[]) {
    setbuf(stdout, NULL);
    int a = 0, b = 0, c = 0;

    printf("Enter three comma-separated numbers: ");
    scanf("%d, %d, %d", &a, &b, &c);
    printf("a = %d \n", a);
    printf("b = %d \n", b);
    printf("c = %d \n", c);
    return (0);
}

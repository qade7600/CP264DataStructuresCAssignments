/*
 * hash.c
 *
 *  Created on: 2019 M03 25
 *      Author: ranaqaderi
 */



#include "hash.h"

int hash(char* word) {
  unsigned int hash = 0, i;
  for (i = 0; word[i] != '\0'; i++) {
    hash = 31 * hash + word[i];
  }
  return hash % htsize;
}

hashnode *new_hashnode(char *name, int value) {
// your implementation
}

hashtable *new_hashtable(int size) {
// your implementation
}

hashnode *search(hashtable *ht, char *name) {
// your implementation
}

int insert(hashtable *ht, hashnode *np) {
// your implementation
}

int delete(hashtable *ht, char *name) {
// your implementation
}

void clean_hash(hashtable **htp) {
  if (*htp == NULL) return;
  hashtable *ht = *htp;
  hashnode *sp = ht->hnp[0], *p, *temp;
  int i;
  for (i = 0; i < ht->size; i++) {
    p = ht->hnp[i];
    while (p) {
      temp = p;
      p = p->next;
      free(temp);
    }
    ht->hnp[i] = NULL;
  }
  free(ht->hnp);
  ht->hnp = NULL;
  *htp = NULL;
}

void display(hashtable *ht) {
  int i = 0;
  hashnode *p;
  printf("size:  %d\n", ht->size);
  printf("count: %d\n", ht->count);
  printf("hash data:\nindex: list of the data elements");
  for (i = 0; i < ht->size; i++) {
    p = *(ht->hnp + i);
    if (p)
      printf("\n%2d: ", i);
    while (p) {
      printf("(%s,%d) ", p->name, p->value);
      p = p->next;
    }
  }
  printf("\n");
}

/*
 ============================================================================
 Project: qade7600_l06t1
 File:    l06t1
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

void strnclean(char *target, const char *source){
	int i = 0;
	char c;

	for(i = 0; source[i]!= '\0'; i++){
		if(isalpha(source[i])){
			c = tolower(source[i]);
			*(target++) = c;
		}
	}
}

int main() {
	char *a1 = "David Brown!";
	char *a2 = (char*)malloc(strlen(a1));
	strnclean(a2, a1);
	printf("Source: %s\nTarget: %s", a1, a2);
	return 0;
}

Name: Rana Qaderi
ID: 170317600
Email: qade7600@mylaurier.ca
WorkID: cp264a4
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1
1. structure design                             [2/3/]
2. import data: load data to data structure     [4/6/]
3. report data: process data, output to file    [4/6/]

Q2
1. set_stopword function                        [4/4/]
2. functions of containing word in dictionary   [4/4/]
3. process_word function                        [2/4/]
4. save_to_file function                        [3/3/]

Total:                                         [/30/]
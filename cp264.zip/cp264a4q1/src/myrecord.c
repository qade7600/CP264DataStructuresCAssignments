
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define MAX_REC 100
#define MAX_LINE 100

typedef struct  {
// your
	char name[20];
	float score;
} RECORD;

char letter_grade(float s);
int import_data(RECORD dataset[], char *filename);       //return the number of records
int report_data(RECORD dataset[], int n, char *filename); //return status

char letter_grade(float s){
// your code
	char letter = 'A';
	if (s < 85 && s >= 70){
		letter = 'B';
	}
	else if (s < 70 && s >= 60){
		letter = 'C';
	}
	else if (s < 60 && s >= 50){
		letter = 'D';
		}
	else if (s < 50 && s >= 0){
			letter = 'f';
			}
	return letter;
}

int import_data(RECORD dataset[], char *filename) {
// your implementation
	FILE *fp;
	fp = fopen(filename, "r");

	if (fp == NULL){
		return 0;
	}

	int n = 0;
	char temp[100];

	while(!feof(fp)){
		fscanf(fp, "%s", temp);
		strcpy(dataset[n].name, strtok(temp, ","));
		dataset[n].score = atof(strtok(NULL, ","));
		n++;
	}
	fclose(fp);
	return n;
}

int report_data(RECORD dataset[], int n, char *filename) {
// your implementation
	FILE *fp;
	fp = fopen(filename, "w");
	int i;
	float a = 0.0;

	for(i = 0; i < n; i++){
		fprintf(fp, "%-15s %c\n", dataset[i].name,letter_grade(dataset[i].score));
		a += dataset[i].score;
	}
	a /= n;
	float v = 0.0;

	for(i = 0; i < n; i++){
		v += (a - dataset[i].score) * (a - dataset[i].score);
	}
		v /= (n-1);
		float std = sqrt(v);
		fprintf(fp, "Record count: %d\n", n);
		fprintf(fp, "Average score: %.2f\n", a);
		fprintf(fp, "Standard deviation: %.2f\n", std);
		printf("Sucessfully saved into %s", filename);
		fclose(fp);
	}

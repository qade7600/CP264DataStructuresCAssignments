#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#define MAX_REC 100
#define MAX_LINE 100



typedef struct record {
	char name[20];
	char s;
} RECORD;

char letter_grade(float s);//s=score
int import_data(RECORD dataset[], char *filename);
int report_data(RECORD dataset[], int n, char *filename);

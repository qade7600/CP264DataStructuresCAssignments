Name: Rana Qaderi
ID: 170317600
Email: qade7600
WorkID: cp264a2
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1
1. correctness of iterative_fibonacci     [/3/]
2. correctness of recursive_fibonacci     [/3/]
3. main function and testing              [/4/]

Q2
1. correctness of honor's algorithm       [/4/]
2. main function                          [/3/]  
3. evaluation & testing                   [/3/]

Q3
1. selection sort                         [/3/]
2. quick sort and correctness             [/3/]
3. other functions                        [/4/] 

Total:                                  [30/30]


Test result:
Q1 output: (copy the screen output of your test run) 
Iterative algorithm measurement:
iterative_fibonacci(40): 102334155
high address: 140732855148952
low address: 140732855148744
memory span: 208
time_span(iterative_fibonacci(40) for 500000 times): 61435.0 (ms)

Recursive algorithm measurement:
iterative_fibonacci(40): 102334155
high address: 140732855148944
low address: 140732855148744
memory span: 200
time_span(iterative_fibonacci(40) for 10 times): 61435.0 (ms)

Comparison of recursive and iterative algorithms:
memory_span(recursive_fibonacci(40))/memory_span(iterative_fibonacci(40)): 1.0
time_span(recursive_fibonacci(40))/time_span(iterative_fibonacci(40)): 50000.0


Q2 output: (copy the screen output of your test run) 
Please enter x value (Ctrl+C or 999 to quit):
0
1.0*0.0^3 + 2.0*0.0^2 + 3.0*0.0^1 + 4.0*0.0^0= 4.0
Please enter x value (Ctrl+C or 999 to quit):
1
1.0*1.0^3 + 2.0*1.0^2 + 3.0*1.0^1 + 4.0*1.0^0= -12682568896239544303616.0
Please enter x value (Ctrl+C or 999 to quit):

Q3 output: (copy the screen output of your test run) 
Array input:
Is sorted:1
Selection sort:
Is sorted:1
Quick sort:
Is sorted:1
time_span(selection_sort(1000) for 10 times): 12258.0 (ms)
time_span(quick_sort(1000) for 1000 times): 83238.0 (ms)
time_span(selection_sort(1000))/time_span(quick_sort(1000)): 14.7

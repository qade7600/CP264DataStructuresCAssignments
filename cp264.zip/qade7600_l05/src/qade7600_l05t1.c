/*
 ============================================================================
 Project: qade7600_l05t1
 File:    l05t1
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */


#include <stdio.h>
#include <stdlib.h>
#include "llist.h"


int main() {
  struct node *start = NULL;
  struct node *np;

  np = new_node(2);
  insert_node_beg(&start, np);
  insert_beg(&start, 1);
  insert_end(&start, 3);
  insert_end(&start, 4);
  insert_end(&start, 5);

  display_forward_iterative(start);

  np = search(start, 4);
  printf("Value found %d\n", get_data(np));

  printf("Delete beginning\n");
  delete_beg(&start);
  display_forward_iterative(start);

  printf("Delete end\n");
  delete_end(&start);
  display_forward_iterative(start);

  printf("Delete node of value %d\n", 4);
  delete(&start, 4);
  display_forward_iterative(start);

  printf("display_forward_recursive\n");
  display_forward_recursive(start);

  printf("display_backward_recursive\n");
  display_backward_recursive(start);

  printf("display_backward_iterative, using additional linked list\n");
  display_backward_iterative(start);
  clean(&start);

  printf("reverse\n");
  reverse(&start);

#ifdef test
  int i ;
  for (i = 0; i< 100000; i++){
    insert_beg(&start, 1);
    delete(&start, 1);
	Sleep(5);
  }
#endif

  return 0;
}


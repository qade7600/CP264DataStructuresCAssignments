#include "llist.h"

struct node* new_node(int num) {
	struct node *np = (struct node *) malloc(sizeof(struct node));
	if (np == NULL)
		return NULL;
	np->data = num;
	np->next = NULL;
	return np;
}

int get_data(struct node *np) {
	return np->data;
}

void set_data(struct node *np, int num) {
	np->data = num;
}

/*
 * time: O(1), space: O(1)
 */
void insert_node_beg(struct node **startp, struct node* new_np) {
	new_np->next = *startp;
	*startp = new_np;
}

/*
 * time: O(1), space: O(1)
 */
void insert_beg(struct node **startp, int num) {
	struct node* np = (struct node *) malloc(sizeof(struct node));
	if (np == NULL) {
		printf("malloc fails");
		return;
	}
	np->data = num;
	np->next = NULL;

	np->next = *startp;
	*startp = np;
}

/*
 * time: O(n), space: O(1)
 */
void insert_end(struct node **startp, int num) {
	struct node *np = (struct node *) malloc(sizeof(struct node));
	if (np == NULL) {
		printf("malloc fails");
		return;
	} //malloc failed
	np->data = num;
	np->next = NULL;

	if (*startp == NULL) {
		*startp = np;
	} else {
		struct node *p = *startp;
		while (p->next != NULL) {
			p = p->next;
		}
		p->next = np;
	}
}

void reverse(struct node *np) {
	if (np == NULL) {
		return;
	}
	reverse(np->next);
	printf("%d", np->data);
}

/*
 * time: O(1), space: O(1)
 */
int delete_beg(struct node **startp) {
	struct node *np = *startp;
	if (np == NULL)
		return 0;
	else {
		*startp = np->next;
		free(np);
		return 1;
	}
}

/*
 * iterative alg, time: O(n), space: O(1)
 */
int delete_end(struct node **startp) {
	if (startp == NULL || *startp == NULL)
		return 0;
	struct node *np = *startp;
	struct node *prev = NULL;

	while (np->next != NULL) {
		prev = np;
		np = np->next;
	}

	if (prev == NULL)
		*startp = NULL;
	else
		prev->next = np->next;

	free(np);
	return 1;

}

/*
 * iterative alg, time: O(n), space: O(1)
 */
int delete(struct node **startp, int num) {
	struct node *np = *startp;
	struct node *prev = NULL;

	while ((np != NULL) && (np->data != num)) {
		prev = np;
		np = np->next;
	}

	if (np == NULL)
		return 0;
	else {
		if (prev == NULL)
			*startp = np->next;
		else
			prev->next = np->next;

#ifdef usefree
		free(np);
#endif

		return 1;
	}
}

/*
 * iterative alg, time: O(n), space: O(1)
 */
struct node* search(struct node *start, int num) {
	while ((start != NULL) && (start->data != num)) {
		start = start->next;
	}
	return start;
}

/*
 * iterative alg, time: O(n), space: O(1)
 */
void display_forward_iterative(struct node *start) {
	printf("Value Address\n");
	while (start != NULL) {
		printf("%5d %d\n", start->data, start);
		start = start->next;
	}
}

/*
 * recursive alg by recursive function call, time: O(n), space: O(n)
 */
void display_forward_recursive(struct node *start) {
	if (start == NULL)
		return;
	printf("%5d %d\n", start->data, start);
	display_forward_recursive(start->next);
}

/*
 * recursive alg by recursive function call, time: O(n), space: O(n)
 */
void display_backward_recursive(struct node *start) {
	if (start == NULL)
		return;
	if (start->next == NULL) {
		printf("%5d %d\n", start->data, start);
	} else {
		display_backward_recursive(start->next);
		printf("%5d %d\n", start->data, start);
	}
}

/*
 * iterative alg, time: O(n), SPACE: O(n), USING ADDITIONAL LINKED LIST AS STACK
 */
void display_backward_iterative(struct node *start) {
	if (start == NULL)
		return;
	struct node* stk = NULL, *ptr;
	while (start != NULL) {
		insert_beg(&stk, start->data);
		start = start->next;
	}

	while (stk != NULL) {
		printf("%5d %d\n", stk->data, stk);
		ptr = stk;
		stk = stk->next;
		free(ptr);
	}
}

/*
 * iterative alg, time: O(n), space: O(1)
 */
int length(struct node *start) {
	int len = 0;
	while (start != NULL) {
		len++;
		start = start->next;
	}
	return len;
}

/*
 * iterative alg, time: O(n), space: O(1)
 */
void clean(struct node **startp) {
	struct node *temp, *np = *startp;
	while (np != NULL) {
		temp = np;
		np = np->next;
		free(temp);
	}
	*startp = NULL;
}

#include <stdio.h>
#include <stdlib.h>

//#define usefree   // uncomment this line to test memory leaking
//#define test     // uncomment this line to test memory leaking
#ifdef test
#include <Windows.h> //for using Sleep(ms) in memory leaking testing
#endif

struct node {
  int data;
#ifdef test
  double ddata[1000]; // scale up for memory leaking test
#endif
  struct node *next;
};

struct node* new_node(int);
int get_data(struct node *);
void set_data(struct node *, int);

int length(struct node *);
void display_forward_iterative(struct node *);
void display_forward_recursive(struct node *);
void display_backward_recursive(struct node *);
void display_backward_iterative(struct node *); //using additional linked list as stack

struct node *search(struct node *, int);

void insert_node_beg(struct node **, struct node*);
void insert_beg(struct node **, int);
void insert_end(struct node **, int);

int delete_beg(struct node **);
int delete_end(struct node **);
int delete(struct node **, int);
void clean(struct node **);

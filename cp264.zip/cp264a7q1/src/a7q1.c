/*
 ============================================================================
 Project: cp264a7q1
 File:    cp264a7q1
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */


#include "tree.h"

int main() {
  // create nodes
  TNODE *a = new_node('A');
  TNODE *b = new_node('B');
  TNODE *c = new_node('C');

  // do linking
  a->left = b;
  a->right = c;
  // more

  // set root
  TNODE *root = a;

  printf("display_tree\n");
  display_tree(root, 0);

  printf("node count:           %d\n", get_count(root));
  printf("tree height:          %d\n", get_height(root));
   // more
  printf("display_preorder:     ");
  	display_preorder(root);
  	printf("\n");
  	printf("display_inorder:      ");
  	display_postorder(root);
  	printf("\n");
  	printf("display_postorder:    ");
  	display_inorder(root);
  	printf("\n");
  	printf("iterative_bf_display: ");
  	iterative_bf_display(root);
  	printf("\n");

  	int val = 'F';
  		printf("iterative_bf_search:  %c\n", val);
  		TNODE* result = iterative_bf_search(root, val);
  		if (result != NULL) {
  			printf("found:                %c\n", result->data);
  		} else {
  			printf("not found:            %c\n", val);
  		}
  		// not found bf:
  		int val2 = 'H';
  		printf("iterative_bf_search:  %c\n", val2);
  		TNODE* result2 = iterative_bf_search(root, val2);
  		if (result2 != NULL) {
  			printf("found:                %c\n", result2->data);
  		} else {
  			printf("not found:            %c\n", val2);
  		}

  		int val3 = 'G';
  		printf("iterative_df_search:  %c\n", val3);
  		TNODE* result3 = iterative_df_search(root, val3);
  		if (result3 != NULL) {
  			printf("found:                %c\n", result3->data);
  		} else {
  			printf("not found:            %c\n", val3);
  		}

  clean_tree(&root);
  return 0;
}

/*
 ============================================================================
 Project: cp264a2q1.c
 File:    polynomial.h
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */
#include<stdio.h>
#include<stdlib.h>

float horner(float x, int n, float p[]);
float bisection(float a, float b, int n, float p[]);

// from a2q2
float horner(float x, int n, float p[])
{
    float value = 0;
    int i;
    for(i = 0; i < n; i++)
        value = value * x + *p++;
    return value;
}

//your bisection method implementation
float bisection(float a, float b, int n, float p[]){
// your implementation
	float tol = 1e-6;
	float c, pa, pc;

	pa = horner(a, n, p);

	do{
		c = (a + b)/ 2;
		pc = horner(c, n, p);
		if(c - a < tol || (pc > 0 && pc < tol) || (pc < 0 && pc >tol)) return c;
		else if((pa > 0 && pc > 0) || (pa < 0 && pc < 0)){
			a = c;
			pa = pc;
		}
		else{
			b = c;
		}

	}while(1);
	return c;
}

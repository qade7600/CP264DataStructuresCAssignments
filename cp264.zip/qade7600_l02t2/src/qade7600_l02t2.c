/*
-------------------------------------
File:    qade7600_l02t2
Project: qade7600_l02t2
 Compute circumference, area and hypotenuse
-------------------------------------
Author:  Rana Qaderi
ID:      170317600
Email:   qade7600@wlu.ca
Version: 2019-01-20
-------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <functions.h>

int main() {
	float r, s1, s2;
	r = atof(argv[1]);
	s1 = atof(argv[2]);
	s2 = atof(argv[3]);

	printf("The circle cirfumference is: %.6f\n", cirfumference(r));
	printf("The circle area is : %.6f\n", area(r));
	printf("The triangle hypoteuse is: %.6f\n", hypotenuse(s1, s2));


	return 0;
}

/* simple BST
 * search, insert, delete by recursive and iterative algorithms
 * HBF
*/
#include<stdlib.h>
#include<stdio.h>

typedef struct tree_node {
  int data;
  struct tree_node *left;
  struct tree_node *right;
} tnode;

// typedef struct tree_node tnode;

// for BST
tnode *recursive_search(tnode *, int); // recursion version
int recursive_insert(tnode **, int); // return 1 if successful, 0 otherwise; recursion version
int recursive_delete(tnode **, int); // return 1 if successful, 0 otherwise; recursion version
tnode *extract_smallest_node(tnode **); // recursion version
tnode *find_smallest_element(tnode *); //return the smallest node, recursion version

// space efficient BST algorithms
tnode *iterative_search(tnode *, int); //recursion version
int iterative_insert(tnode **, int);   //return 1 if successful, 0 otherwise; recursion version
int iterative_delete(tnode **, int);   //return 1 if successful, 0 otherwise; recursion version
tnode *iterative_extract_smallest_node(tnode **); // iterative version
tnode *iterative_find_largest_element(tnode *);  //return the smallest node, iterative version

// for general binary tree
tnode *new_node(int);
void print_preorder(tnode *);
void print_inorder(tnode *);
void print_postorder(tnode *);
void print_tree(tnode *, int);
void clean_tree(tnode **);

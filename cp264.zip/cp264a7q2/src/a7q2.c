/*
 ============================================================================
 Project: cp264a7q1
 File:    cp264a7q1
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"
#include "markstats.h"

int main(int argc, char* args[]) {
  char infilename[40] = "marks.txt";
  char outfilename[40] = "report.txt";
  if (argc > 1) {
    if (argc >= 2) strcpy(infilename, args[1]);
    if (argc >= 3) strcpy(outfilename, args[2]);
  }

  //create and initiate MARKS and bst data structure
  printf("\n1. declare and initialize a MARKS variable\n");
  MARKS dataset;
  dataset.bst = NULL;
  dataset.count = 0;
  dataset.mean = 0;
  dataset.stddev = 0;

  printf("\n2. import_data\n");

  //import mark records into bst data structure and
  import_data(&dataset, infilename);

  printf("\n3. display_inorder\n");
  display_inorder(dataset.bst);

  printf("\n4. display_stats\n");
  display_stats(&dataset);

  printf("\n5. add_data: Moore,92.0\n");
  add_data(&dataset, "Moore", 92.0);
  printf("\nadd_data: Fan,88.0\n");
  add_data(&dataset, "Fan", 88.0);
  printf("\nadd_data: Lu,85.0\n");
  add_data(&dataset, "Lu", 85.0);

    printf("\n6. search: Moore\n");
  TNODE *tp = search(dataset.bst, "Moore");
  if (tp== NULL)
    printf("\nNot Fount\n");
  else
    printf("\nFound: (%s, %3.1f)\n", tp->data.name, tp->data.score);


  printf("\n7. remove_data: Wang\n");
  remove_data(&dataset, "Wang");

  printf("\nremove_data: Chabot\n");
  remove_data(&dataset, "Chabot");

  printf("\n8. report_data\n");
  report_data(&dataset, outfilename);

  printf("\n9. clean\n");
  clean_tree(&dataset.bst);

  return 0;
}

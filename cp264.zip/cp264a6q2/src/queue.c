#include "queue.h"

void enqueue(QNODE **frontp, QNODE **rearp, int val) {
// your code
	QNODE *np = (QNODE *) malloc(sizeof(QNODE));
	np->data = val;
	np->next = NULL;
	if (*frontp == NULL && *rearp == NULL) {
		*frontp = np;
		*rearp = np;
	} else {
		(*rearp)->next = np;
		(*rearp) = np;
	}
}

int dequeue(QNODE **frontp, QNODE **rearp) {
// your code
	QNODE *np = (QNODE *) malloc(sizeof(QNODE));
	np = *frontp;
	int ans = 0;
	if (*frontp == NULL) {
		return ans;
	} else {
		ans = np->data;
		if (frontp == rearp) {
			*frontp = NULL;
			*rearp = NULL;
		} else {
			*frontp = (*frontp)->next;
			np->next = NULL;
			free(np);
		}
		return ans;
	}
}

int peek(QNODE *front) {
// your code
	if (front == NULL) {
		printf("\nQUEUE IS EMPTY");
		return -1;
	} else
		return front->data;
}

void clean(QNODE **frontp, QNODE **rearp) {
// your code
	if (*frontp != NULL) {
		QNODE *temp, *ptr = *frontp;

		while (*frontp != NULL) {
			temp = ptr;
			ptr = ptr->next;
			free(temp);
		}
		*frontp = NULL;
		*rearp = NULL;
	}
}

/*
 ============================================================================
 Project: cp264a2q1
 File:    a2q1.c
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include <stdio.h>
#include <time.h>

int *la;
int *ha;

int iterative_fibonacci(int n)
{
int f,i;
int numFront=1,numBack=1,temp;
    if (&n < la) la = &n;  // to the memory address of local variable for memory usage.
if (n<=2){
return 1;
}
else{
for (i=3;i<=n;i++){
temp=numFront;
numFront=numFront+numBack;
numBack=temp;
}
}
return numFront;
}


int recursive_fibonacci(int n) {
	if (&n < la)
		la = &n;
	// your implementation
	if ( n <= 2) return 1;
	else return recursive_fibonacci(n-1) + recursive_fibonacci(n-2);

}

int main(){
    int i = 0, n = 40, c = 0;
    clock_t t1, t2, t3, t4;

    printf("Iterative algorithm measurement:\n");
    //memory measuring for iterative_fibonacci
    ha = &i;
    la = ha;
    printf("iterative_fibonacci(%d): %d\n", n, iterative_fibonacci(n));
    printf("high address: %lu\n", ha);
    printf("low address: %lu\n", la);

    int memory_span1 = (unsigned long) ha - (unsigned long) la;
    printf("memory span: %d\n",memory_span1);

    //run time measuring for iterative_fibonacci
    int m1 = 500000;
    t1 = clock();
    for (i=0; i< m1; i++) {
        iterative_fibonacci(n);
    }
    t2 = clock();
    double time_span1 = (double) t2 - t1;
    printf("time_span(iterative_fibonacci(%d) for %d times): %0.1f (ms)\n", n, m1, time_span1);

    printf("\nRecursive algorithm measurement:\n");

    // add your memory span and time span measuring for recursive_fibonacci

    ha = &c;
    la = ha;
    printf("iterative_fibonacci(%d): %d\n", n, iterative_fibonacci(n));
    printf("high address: %lu\n", ha);
    printf("low address: %lu\n", la);

    int memory_span2 = (unsigned long) ha - (unsigned long) la;
    printf("memory span: %d\n",memory_span2);

    int m2 = 10;
    t3 = clock();
    for (c = 0; c < m2; c++) {
            iterative_fibonacci(n);
        }
    t4 = clock();
    double time_span2 = (double) t2 - t1;
    printf("time_span(iterative_fibonacci(%d) for %d times): %0.1f (ms)\n", n, m2, time_span2);



    // comparison
    printf("\nComparison of recursive and iterative algorithms:\n");

    printf("memory_span(recursive_fibonacci(%d))/memory_span(iterative_fibonacci(%d)): %0.1f\n", n, n, ((double) memory_span2)/memory_span1);

    printf("time_span(recursive_fibonacci(%d))/time_span(iterative_fibonacci(%d)): %0.1f\n", n, n, (time_span2 / time_span1)*(m1/m2));

    return 0;
}

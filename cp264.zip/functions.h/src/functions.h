/*
-------------------------------------
File:    functions.h
Project: lab02_solution
 Circle functions header
-------------------------------------
Author:  Rana Qaderi
ID:      170317600
Email:   qade7600@wlu.ca
Version: 2019-01-20
-------------------------------------
*/

#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

double circumference(double radius);

double area(double radius);

double hypotenuse(double side1, double side2);

double volume(double radius);

#endif /* FUNCTIONS_H_ */

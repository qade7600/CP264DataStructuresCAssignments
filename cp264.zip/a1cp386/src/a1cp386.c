/*
 ============================================================================
 Name        : a1cp386.c
 Author      : Rana
 Version     :
 Copyright   : 
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	puts(""); /* prints  */
	return EXIT_SUCCESS;
}

Name:Rana Qaderi
ID: 170317600
Email: qade7600@mylaurier.ca
WorkID: cp264a5
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1
1. display records in linked list               [3/3/]
2. search function                              [3/3/] 
3. insert function                              [3/3/]
4. delete function                              [3/3/]  
5. clean function                               [3/3/]

Q2 
1. new node, display forward/backward functions [4/4/]
3. insert start/end functions                   [4/4/]
4. delete start/end functions                   [4/4/]
5. clean function                               [3/3/]
		
Total:                                         [30/30/] 
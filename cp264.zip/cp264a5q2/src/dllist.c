#include "dllist.h"

NODE *new_node(char data) {
// your code
	NODE*np = (NODE*) malloc(sizeof(NODE));
	np->data = data;
	np->prev = NULL;
	np->next = NULL;
	return np;

}

void display_forward(NODE *np) {
// your code
	while (np != NULL) {
		printf(" %c ", np->data);
		np = np->next;
	}
}

void display_backward(NODE *np) {
// your code
	while (np != NULL) {
		printf(" %c ", np->data);
		np = np->prev;
	}
}

void insert_start(NODE **startp, NODE **endp, NODE *new_np) {
// your code
	if (*startp == NULL) {
		*startp = new_np;
		*endp = new_np;
		new_np->prev = NULL;
		new_np->next = NULL;
	} else {
		(*startp)->prev = new_np;
		new_np->prev = NULL;
		new_np->next = *startp;
		*startp = new_np;
	}

}

void insert_end(NODE **startp, NODE **endp, NODE *new_np) {
// your code
	if (*endp == NULL) {
		new_np->next = NULL;
		new_np->prev = NULL;
		*endp = new_np;
		*startp = new_np;
	} else {
		new_np->next = NULL;
		new_np->prev = *endp;

		(*endp)->next = new_np;
		*endp = new_np;
	}

}

void delete_start(NODE **startp, NODE **endp) {
// your code
	if (*startp == NULL) {
		return;
	} else if (*startp == *endp) {
		free(*startp);
		*startp = NULL;
		*endp = NULL;
	} else {

		NODE* temp = *startp;
		*startp = (*startp)->next;
		(*startp)->prev = NULL;
		free(temp);
	}

}

void delete_end(NODE **startp, NODE **endp) {
// your code
	if (*endp == NULL) {
		return;
	} else if (*startp == *endp) {
		free(*startp);
		*startp = NULL;
		*endp = NULL;
	} else {
		NODE* temp = *endp;
		*endp = (*endp)->prev;
		(*endp)->next = NULL;
		free(temp);
	}

}

void clean(NODE **startp, NODE **endp) {
// your code
	NODE *ptr = *startp, *temp;
	while (ptr != NULL) {
		temp = ptr;
		ptr = ptr->next;
		free(temp);
	}
	*startp = NULL;
	*endp = NULL;

}

/*
 * simple max-heap,  HBF
*/

#include <stdio.h>
#define MAX 100

void display_heap(int *);
void display_array(int *, int);
int find_max(int *);
void insert(int*, int);
void delete(int *);
void heapify_down(int *, int, int);
void heapify_up(int *, int);
void heap_sort_heap(int *);            //heap sort for given heap,
void heap_sort_array(int a[], int n);  //heap sort for given array, in place

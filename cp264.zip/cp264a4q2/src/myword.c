#include "myword.h"

void set_stopword(char *filename, char *stopwords[]) {
// your implementation, refer to class code example 22 -- csv file read with string value
	char line[1000];
	char delimiters[] = ".,\n\t\r";
	char *token;
	int i;

	while (fgets(line, 1000, filename) != NULL) {
		token = (char*) strtok(line, delimiters);
		while (token != NULL) {
			i = (int) (*token - 'a');
			if (*stopwords[i] == '\0')
				strcat(stopwords[i], ",");
			strcat(stopwords[i], token);
			strcat(stopwords[i], ",");
			token = (char*) strtok(NULL, delimiters);
		}
	}
}

// this function check if the word is contained in directory stopwords[]
// returns 1 if yes, 0 otherwise. It use function str_contain_word()
int contain_word(char *stopwords[], char *word) {
// your code
	int x = str_contain_word(stopwords[*word - 'a'], word);
	return x;
}

// this function check if word is a word in string str,
// returns 1 if yes, 0 otherwise
int str_contain_word(char *str, char *word) {
	if (str == NULL || word == NULL)
		return 0;

	// your code
	int x;
	char temp[20] = { 0 };
	strcat(temp, ",");
	strcat(temp, word);
	strcat(temp, ",");

	if (strstr(str, temp)) {
		x = 1;
	} else {
		x = 0;
	}

	return x;
}

int process_word(char *filename, WORDSUMMARY *words, char *stopwords[]) {
	FILE *fp;
	char *word_token;
	const char delimiters[] = " .,;:!()&?-\n\t\r\"\'";
	char line[MAX_LINE_LEN];
	if ((fp = fopen(filename, "r")) != NULL) {
		while (fgets(line, MAX_LINE_LEN, fp) != NULL) {
			words->line_count++;
			lower_case(line);
			trim(line);
			word_token = (char*) strtok(line, delimiters);
			while (word_token != NULL) {
				words->word_count++;
				if ((contain_word(stopwords, word_token) == 0)) {
					int i = 0;
					int flag = 1;
					while (i < words->keyword_count) {
						if (strstr(words->word_array[i].word, word_token)) {
							flag = 0;
							words->word_array[i].frequency++;
						}
						i++;
					}
					if (flag) {
						strcpy(words->word_array[words->keyword_count].word,
								word_token);
						words->keyword_count++;
						words->word_array[i].frequency++;
					}
				}
				word_token = (char*) strtok(NULL, delimiters);
			}
		}
	}
	return 0;
}

int save_to_file(char *filename, WORDSUMMARY *words) {
// your implementation, use the following formats
	FILE *fp;
	int i = 0;
	if ((fp = fopen(filename, "w")) != NULL) {
		fprintf(fp, "%-20s  %8d\n", "Line count", words->line_count);
		fprintf(fp, "%-20s  %8d\n", "Word count", words->word_count);
		fprintf(fp, "%-20s  %8d\n", "Keyword count", words->keyword_count);
		fprintf(fp, "%-18s  %10s\n", "Keyword", "frequency");
		while (i < words->keyword_count) {
			fprintf(fp, "%-20s  %8d\n", words->word_array[i].word,
					words->word_array[i].frequency);

			i++;
		}
	}
	return 0;
}

/* mystring.c
author: HBF
version: 2019-01-15
*/
#include "mystring.h"

int str_length(char *s) {
    if (s == NULL) return -1;
	int counter = 0;
	while (*s) {counter++; s++;}
	return counter;
}

int word_count(char *s) {
	if (s == NULL || *s == '\0') return 0;
	int counter = 0;
	char *p = s;
	while (*p) {
		if (*p != ' ' && (p==s || *(p-1) == ' ')) {
			counter++;
		}
		p++;
	}
	return counter;
}

void lower_case(char *s) {
	if (s == NULL) return;
	while (*s) {
		if (*s >= 'A' && *s <= 'Z' ) *s += 32;
		s++;
	}
}

void trim(char *s) {
	if (s == NULL || *s == '\0') return;
	char *p=s,*dp=s;
	while (*p) {
	   if (*p != ' ' || (p > s && *(p-1) != ' ')) {
		  *dp = *p;
		  dp++;
	   }
       p++;
	}

	if (*(p-1) == ' ') *(dp-1) = '\0';
	else *dp = '\0';
}

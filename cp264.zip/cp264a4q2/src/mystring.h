/* mystring.h
author: qade7600
version: 2019-01-15
*/
#include <stdio.h>

int str_length(char *);
int word_count(char *);
void lower_case(char *);
void trim(char *);

/*
 * graph_a1.c
 *
 *  Created on: 2019 M03 26
 *      Author: ranaqaderi
 */

#include "graph_a1.h"

void random_graph(node *adj[], int node_number) {
  node *new_node, *last;
  int i, j, k, h, d, val, flag;
  int neighbors[node_number];
  srand(time(NULL));

  for (i = 0; i < node_number; i++) {
    last = NULL;
    d = rand() % node_number;

    flag = 1;
    neighbors[0] = i;

    for (k = 1; k <= d; k++) {
      val = rand() % node_number;

      while (flag) {
        val = rand() % node_number;
        for (h=0; h<k; h++) {
          if (val == neighbors[h]) break;
        }
        if (h >= k) flag = 0;
      }

      neighbors[k] = val;
      flag = 1;
    }

    for (j = 1; j <= d; j++) {
      new_node = (node *) malloc(sizeof(node));
      new_node->vertex = neighbors[j];
      new_node->next = NULL;
      if (adj[i] == NULL)
        adj[i] = new_node;
      else
        last->next = new_node;
      last = new_node;
    }
  }
}

void  bidirect_graph(node *adj[], int node_number) {
  node *new_node;
  int i, j;

  node *c,  *prev = NULL, *p = NULL;

  for (i = 0; i < node_number; i++) {
    c = adj[i];

    while (c) {
      j = c->vertex;
      prev = NULL;
      p = adj[j];
      while (p) {
        if (p->vertex == i) {
          break;
        }
        else {
          prev = p;
          p = p->next;
        }
      }
      if (p==NULL) {
        new_node = (node *) malloc(sizeof(node));
        new_node->vertex = i;
        new_node->next = NULL;

        if (prev == NULL) {
          adj[j] = new_node;
        } else {
          prev->next = new_node;
        }
      }
      c = c->next;
    }
  }
}

void create_graph(node *adj[], int node_number) {
  node *new_node, *last;
  int i, j, n, val;
  for (i = 0; i < node_number; i++) {
    last = NULL;
    printf("\nEnter the number of neighbors of %d: ", i);
    scanf("%d", &n);
    for (j = 1; j <= n; j++) {
      printf("\nEnter the neighbor %d of %d: ", j, i);
      scanf("%d", &val);
      new_node = (node *) malloc(sizeof(node));
      new_node->vertex = val;
      new_node->next = NULL;
      if (adj[i] == NULL)
        adj[i] = new_node;
      else
        last->next = new_node;
      last = new_node;
    }
  }
}

void display_graph(node *adj[], int node_number) {
  node *ptr;
  int i;
  for (i = 0; i < node_number; i++) {
    ptr = adj[i];
    printf("\nnode %d neighbors:", i);
    while (ptr != NULL) {
      printf(" %d", ptr->vertex);
      ptr = ptr->next;
    }
  }
}

int add_edge(node *adj[], int n, int from, int to) {
  if (0 > from || from > n || 0 > to || to > n) return -1;

  node *prev = NULL, *ptr = adj[from];
  while (ptr != NULL) {
    if (ptr->vertex == to) return 0;
    else {
      prev = ptr;
      ptr = ptr->next;
    }
  }
  if (ptr==NULL) {
    node *new_node = (node *) malloc(sizeof(node));
    new_node->vertex = to;
	new_node->next = NULL;

    if (prev == NULL) {
      adj[from] = new_node;
    } else {
      prev->next = new_node;
    }
  }
  return 1;
}

int delete_edge(node *adj[], int n, int from, int to) {
  if (0 > from || from > n || 0 > to || to > n) return -1;
  node *prev = NULL, *ptr = adj[from];
  while (ptr != NULL) {
    if (ptr->vertex == to) {
      if (prev == NULL) {
        adj[from] = ptr->next;
        free(ptr);
      } else {
        prev->next = ptr->next;
        free(ptr);
      }
      return 1;
    } else {
      prev = ptr;
      ptr = ptr->next;
    }
  }
  return 0;
}

void delete_graph(node *adj[], int node_number) {
  int i;
  node *temp, *ptr;
  for (i = 0; i <node_number; i++) {
    ptr = adj[i];
    while (ptr != NULL) {
      temp = ptr;
      ptr = ptr->next;
      free(temp);
    }
    adj[i] = NULL;
  }
  printf("\nGraph is deleted");
}

void breadth_first_search(node *adj[], int size, int visited[], int start) {
  int queue[size], rear = -1, front = -1, i;
  queue[++rear] = start;
  visited[start] = 1;
  node *p = NULL;
  while (rear != front) {
    start = queue[++front];
    printf("%d ", start);
    p = adj[start];
    while (p) {
      i = p->vertex;
      if (visited[i] == 0) {
        visited[i] = 1;
        queue[++rear] = i;
      }
      p = p->next;
    }
  }
}


void depth_first_search_iterative(node *adj[], int size, int visited[], int start)
{
  int stack[size];
  int top = -1, i;
  visited[start] = 1;
  stack[++top] = start;
  node *p = NULL;
  while (top != -1) {
    start = stack[top--];
    printf("%d ", start);
    p = adj[start];
    while (p) {
      i = p->vertex;
      if (visited[i] == 0) {
        stack[++top] = i;
        visited[i] = 1;
      }
      p = p->next;
    }
  }
}

void depth_first_search_recursive(node *adj[], int size, int visited[], int start)
{
  int i;
  node *p = NULL;
  visited[start] = 1;
  printf("%d ", start);
  p = adj[start];
  while (p) {
    i = p->vertex;
    if (visited[i] == 0) {
      depth_first_search_recursive(adj, size, visited, i);
    }
    p = p->next;
  }
}

int reach_count(node *adj[], int size, int start)
{
  int stack[size], i;
  int visited[size];
  for (i = 0; i<size; i++) visited[i] = 0;
  int top = -1;
  visited[start] = 1;
  stack[++top] = start;
  node *p = NULL;
  while (top != -1) {
    start = stack[top--];
    p = adj[start];
    while (p) {
      i = p->vertex;
      if (visited[i] == 0) {
        stack[++top] = i;
        visited[i] = 1;
      }
      p = p->next;
    }
  }
  int count = 0;
  for (i = 0; i<size; i++)
    if (visited[i] == 1) count++;

  return count;
}

void node_counts(node *adj[], int n)
{
    int count = 0;
    node *ptr = adj[n];
    printf("node %d count: ", n);
    if(ptr == NULL)
    {
        printf("%d\n", count);
    }
    else
    {
        while(ptr)
        {
            count++;
            ptr = ptr->next;
        }
        printf("%d\n", count);
    }
}

/*
 * expeval.c
 *
 *  Created on: 2019 M03 25
 *      Author: ranaqaderi
 */



#include "expeval.h"


void display_name_value(hashtable *ht) {
// your implementation
}

int evaluate_infix(char *infixstr, hashtable *ht) {
// your implementation
  return 0;
}

/* this is to process an assignment statement,
 * the left side is a name
 * the right side is an expression, which needs to be evaluated,
 * after evaluation insert the name and value pair into hash table.
 * return 1 if successful, 0 otherwise
*/
int resolve_assignment(char* statement, hashtable *ht) {
// your implementation
  return 0;
}


/* this function is adapted from infix_to_postfix of a6q4
 * add the case when an expression contains a symbol name.
*/
void infix_to_postfix(char *infixstr, NODE **frontp, NODE **rearp, hashtable *ht) {
  NODE *top=NULL;
  char *p = infixstr;
  int sign = 1;
  int num = 0;
  char symbol[11] = {0};

  while (*p) {
    if ( *p == '-' && (p == infixstr || *(p-1) == '(')  ) {
      sign = -1;
    }
    else if (*p >= '0' && *p <= '9'){
      num=*p-'0';
      while ((*(p+1) >= 48 && *(p+1) <= 57)) {
        num = num*10 + *(p+1)-'0';
        p++;
      }
      enqueue(frontp, rearp, new_node(sign*num, 0));
      sign = 1;
    }
    else if (*p == '(') {
      push(&top, new_node('(', 3));
    }
    else if (*p == ')') {
      while (top){
        if (top->type == 3) {
          free(pop(&top));
          break;
        }
        enqueue(frontp, rearp, pop(&top));
      }
    }
    else if (is_operator(*p)) {
      while (top && top->type==1 && get_priority( top->data) >= get_priority(*p))
        enqueue(frontp, rearp, pop(&top));
      push(&top, new_node(*p, 1));
    }
    else if ( (*p >= 'a' && *p <= 'z') || (*p >=  'A' && *p <= 'Z') ){

      /* this case is when a symbol name is encountered, it needs to get the symbol's
      value from hash table. If found, use its value as an operant. If  not found, clean up stack and queue, and return.
      */
    }

    p++;
  } // end of scan while loop

  while (top) {
    enqueue(frontp, rearp, pop(&top));
  }
}


//following functions are adapted from a6q4
int evaluate_postfix(NODE *front) {
  NODE *top = NULL;
  int type = 0;
  NODE *p = front;

  while (p) {
    type = p->type;
    if (type == 0) {    // operant
      push(&top, new_node(p->data, 0));
    }
    else if (type==1){  // operator
      int operator = p->data;
      NODE *oprand2 = pop(&top);

      if (operator == '+')
        top->data = top->data + oprand2->data;
      else if (operator == '-')
        top->data = top->data - oprand2->data;
      else if (operator == '*')
        top->data = top->data * oprand2->data;
      else if (operator == '/')
        top->data = top->data / oprand2->data;
      else if (operator == '%')
        top->data = top->data & oprand2->data;

      free(oprand2);
    }
    p = p->next;
  }
  int result = top->data;
  clean(&top);
  return result;
}

int get_priority(char op) {
  if (op == '/' || op == '*' || op == '%') return 1;
  else if (op == '+' || op == '-') return 0;
  return 0;
}

int is_operator(char op) {
  if (op == '/' || op == '*' || op == '%' || op == '+' || op == '-')
    return 1;
  else
    return 0;
}

int is_symbol(char s) {
  if (!is_operator(s) && (s < '0' || s > '9') && s != ')' && s != '(') {
    return 1;
  } else
    return 0;
}

NODE *new_node(int data, int type) {
  NODE *np = (NODE *) malloc(sizeof(NODE));
  np->data = data;
  np->type = type;
  np->next = NULL;
}

void push(NODE **topp, NODE *np) {
  if (*topp == NULL) {
    *topp = np;
    np->next = NULL;
  }
  else {
    np->next = *topp;
    *topp = np;
  }
}

NODE *pop(NODE **topp) {
  if (*topp) {
    NODE *tmp = *topp;
    *topp = tmp->next;
    tmp->next = NULL;
    return tmp;

  } else
  return NULL;
}

void enqueue(NODE **frontp, NODE **rearp, NODE *np) {
  if (*frontp == NULL) {
    *frontp = np;
    *rearp = np;
    np->next = NULL;
  }
  else {
    (*rearp)->next = np;
    *rearp = np;
  }
}

NODE *dequeue(NODE **frontp, NODE **rearp) {
  NODE *ptr = *frontp;
  if (ptr == NULL) return NULL;
  if (ptr == *rearp) {
      *frontp = NULL;
    *rearp = NULL;
  }
  else {
     *frontp = ptr->next;
  }
  return ptr;
}

void display_forward(NODE *start) {
  while (start) {
    if (start->type == 0)
      printf("%d ", start->data);
      else
          printf("%c ", start->data);

    start = start->next;
  }
}

void clean(NODE **startp) {
  NODE *curr = *startp;
  while (curr) {
    NODE *tmp = curr;
    curr = curr->next;
    free(tmp);
  }
  *startp = NULL;
}


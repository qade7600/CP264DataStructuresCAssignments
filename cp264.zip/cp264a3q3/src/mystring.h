/*
 ============================================================================
 Project: cp264a3q3.c
 File:    mystring.h
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */
#include <stdio.h>

int str_length(char *);
int word_count(char *);
void lower_case(char *);
void trim(char *);

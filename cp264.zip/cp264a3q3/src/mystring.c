/*
 ============================================================================
 Project: cp264a3q3.c
 File:    mystring.c
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include "mystring.h"

int str_length(char *s) {
// your implementation, refer to lecture note
	if (s == NULL) return -1;
	int counter = 0;
	char *p = s;
	while (*p){
		counter++;
		p++;
	}
	return counter;
}

int word_count(char *s) {
// your implementation
	if (s == NULL || *s == '\0') return 0;
	int counter = 0;
	char *p = s;
	while (*p){
		if(*p != ' ' && (p == s || *(p-1) == ' ')){
			counter++;
		}
		p++;
	}
	return counter;
}

void lower_case(char *s) {
// your implementation
	if (s == NULL) return;
	char *p = s;
	while (*p){
		if((*p >= 'A') && (*p <= 'Z'))*p += 32;
		p++;
	}
}

void trim(char *s) {
// your implementation
	char *p = s, *dp = s;
	while(*p){
		if(*p != ' ' || (p > s && *(p - 1) != ' ')) {
			*dp = *p;
			dp++;
		}
		p ++;
	}
	if(*(p-1) == ' ') {
		*(dp - 1) = '\0';
	}
	else *dp = '\0';
	printf("\n%s", s);
}

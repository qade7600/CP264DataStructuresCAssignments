/*
 ============================================================================
 Project: cp264a3q3.c
 File:    a3q3.c
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include "mystring.h"

int main(int argc, char* args[]) {
    setbuf(stdout, NULL);
    char str[100] = "     This Is    a Test   ";
    printf("\nWord count:%d", word_count(str));
    printf("\nBefore trimming:\"%s\"", str);
    printf("\nlength:%d", str_length(str));
    trim(str);
    lower_case(str);
    printf("\nAfter trimming:\"%s\"", str);
    printf("\nlength:%d", str_length(str));
    return 0;
}

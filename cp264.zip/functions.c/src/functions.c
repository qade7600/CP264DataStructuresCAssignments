/*
-------------------------------------
File:    functions.c
Project: lab02_solution
 Circle functions definitions
-------------------------------------
Author:  Rana Qaderi
ID:      170317600
Email:   qade7600@wlu.ca
Version: 2019-01-20
-------------------------------------
*/
#include <math.h>

#define PI 3.1416   // define PI as a macro value

double circumference(double radius) {
	return (2 * PI * radius);
}

double area(double radius) {
	return (PI * pow(radius, 2));
}

double hypotenuse(double side1, double side2) {
	return (sqrt(pow(side1, 2) + pow(side2, 2)));
}

double volume(double radius) {
	return ((double)4/3) * PI * (pow(radius, 3));
}

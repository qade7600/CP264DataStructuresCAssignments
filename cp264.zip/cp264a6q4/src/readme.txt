Name: Rana Qaderi
ID: 170317600
Email: qade7600@mylaurier.ca
WorkID: cp264a6
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1 
1. add function                                  [/4/]
2. Fibonacci function                            [/4/]

Q2
1. enqueue and dequeue functions                 [/4/]
2. peek and clean functions                      [/3/] 

Q3
1. push and pop functions                        [/4/]
2. peek and clean functions                      [/3/] 

Q4
1. infix_to_postfix function                     [/4/]
2. evaluate_postfix function                     [/4/] 

Total:                                          [/30/] 
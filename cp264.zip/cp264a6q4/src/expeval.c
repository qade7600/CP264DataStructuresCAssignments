#include "expeval.h"

void infix_to_postfix(char *infixstr, NODE **frontp, NODE **rearp) {
// new program for a6q4
	NODE *stack = (NODE *) malloc(sizeof(NODE));
		NODE *ptr;
		char *stringInput = infixstr;
		push(&stack, new_node('(', 1));
		while (*stringInput) {
			if (*stringInput == '(' || is_operator(*stringInput)) {
				push(&stack, new_node(*stringInput, 1));
			} else if (isdigit(*stringInput)) {
				enqueue(frontp, rearp, new_node(*stringInput, 0));
			} else if (*stringInput == ')') {
				ptr = pop(&stack);
				while (ptr->data != '(') {
					enqueue(frontp, rearp, ptr);
					ptr = pop(&stack);
				}
			}
			stringInput++;
		}
		ptr = pop(&stack);
		while (ptr->data != '(') {
			enqueue(frontp, rearp, ptr);
			ptr = pop(&stack);
		}
}

int evaluate_postfix(NODE **frontp, NODE **rearp) {
// new program for a6q4
	NODE *stack = (NODE *) malloc(sizeof(NODE));
		NODE *nodePointer = *frontp;
		NODE *operand1, *operand2;
		while (nodePointer != NULL) {
			if (nodePointer->data >= '0' && nodePointer->data <= '9') {
				push(&stack, new_node(nodePointer->data - '0', 0));
			} else if (nodePointer->data == '/' || nodePointer->data == '*'
					|| nodePointer->data == '%' || nodePointer->data == '+'
					|| nodePointer->data == '-') {
				operand2 = pop(&stack);
				operand1 = pop(&stack);
				if (get_priority(nodePointer->data)) {
					if (nodePointer->data == '%')
						push(&stack, new_node(operand1->data % operand2->data, 0));
					else if (nodePointer->data == '*')
						push(&stack, new_node(operand1->data * operand2->data, 0));
					else if (nodePointer->data == '/')
						push(&stack, new_node(operand1->data / operand2->data, 0));
				} else {
					if (nodePointer->data == '-')
						push(&stack, new_node(operand1->data - operand2->data, 0));
					else if (nodePointer->data == '+')
						push(&stack, new_node(operand1->data + operand2->data, 0));
				}
			}
			nodePointer = nodePointer->next;
		}
		return pop(&stack)->data;
}

int get_priority(char op) {
    if (op == '/' || op == '*' || op == '%') return 1;
    else if (op == '+' || op == '-') return 0;
    return 0;
}

int is_operator(char op) {
    if (op == '/' || op == '*' || op == '%' || op == '+' || op == '-')
        return 1;
    else
        return 0;
}

int is_symbol(char s) {
    if (!is_operator(s) && !isdigit(s) && s != ')' && s != '(') {
        return 1;
    } else
        return 0;
}


NODE *new_node(int data, int type) {
    NODE *np = (NODE *) malloc(sizeof(NODE));
    np->data = data;
    np->type = type;
    np->next = NULL;
}

void push(NODE **topp, NODE *np) {
// adapted from a6q3
	if (*topp == NULL) {
			(*topp) = np;
		} else {
			np->next = (*topp);
			(*topp) = np;
		}
}

NODE *pop(NODE **topp) {
// adapted from a6q3
	NODE* return_pointer = *topp;
		// check for stack underflow
		if (*topp == NULL) {
			return_pointer = NULL;
			printf("\nNOTHING TO POP");
		} else {
			*topp = (*topp)->next;
		}
		return return_pointer;
}

void enqueue(NODE **topp, NODE **bottom, NODE *np) {
// adapted from a6q2
	NODE *new_node = (NODE*) malloc(sizeof(NODE));
		new_node = np;
		new_node->next = NULL;
		if (*topp == NULL && *bottom == NULL) {
			*topp = new_node;
			*bottom = *topp;
		} else {
			(*bottom)->next = new_node;
			*bottom = new_node;
		}
}

NODE *dequeue(NODE **frontp, NODE **rearp) {
// adapted from a6q2
	NODE *tmp = NULL;
		if (*frontp != NULL) {
			if (*frontp == *rearp) {
				*frontp = NULL;
				*rearp = NULL;
				tmp = NULL;
			} else {
				tmp = *frontp;
				*frontp = (*frontp)->next;
				free(tmp);
			}
		}
		return tmp;
}

void display_forward(NODE *start) {
// adapted from a6q1
	while (start != NULL) {
			printf("%c ", start->data);
			start = start->next;
		}
}

void clean(NODE **startp) {
// adapted from a6q1
	NODE *ptr = *startp, *temp;
		while (ptr != NULL) {
			temp = ptr;
			ptr = ptr->next;
			free(temp);
		}
		*startp = NULL;
}

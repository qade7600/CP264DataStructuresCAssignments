/*
 ============================================================================
 Project: cp264a1q1
 File:    a1q1.c
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>

int main() {
    //the following two lines are for Eclipse console none-buffered output, in case you use Eclipse to do your assignment
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    char c = 0, temp;


    do {
        printf("Please enter a character:\n");
        scanf("%c", &c); //this is to get  character input from keyboard

        do { // this loop is to get rid of additional characters in stdin buffer
            scanf("%c", &temp);
            if (temp == '\n') break;


        } while (1);


        if (c >= 'a' && c <= 'z'){
        	printf("%c %d %c\n", c, c, c-32);
            }
        else if (c >= 'A' && c <= 'Z'){
        	printf("%c %d %c\n", c, c, c+32);
        }
        else if (c == '*') break;
        else{
        	printf("Invalid input\n");
        }


    } while (1);
    printf("Goodbye\n");
    return 0;
}

/*
 * graph.c
 *
 *  Created on: 2019 M03 28
 *      Author: ranaqaderi
 */

#include"graph.h"


/* create and return a new adjacent list graph of order n */
GRAPH *new_graph(int vertex_number) {
// your implementation
	GRAPH *ptr = (GRAPH*) malloc(sizeof(GRAPH));
	ptr->size = 0;
	ptr->order = vertex_number;
	ptr->adjlist = (ADJNODE**) malloc(sizeof(ADJNODE*));
	for(int i = 0; i < vertex_number; i++){
		ptr->adjlist[i] = NULL;
	}
	return ptr;
}

/* add a new edge (from, to, weight) to the
graph passed by GRAPH *g, if the edge (from, to) exists, update its weight*/
void add_edge(GRAPH *g, int from, int to, int weight) {
	ADJNODE *ptr = g->adjlist[from], *prev = NULL;
	ADJNODE *new_node = (ADJNODE*) malloc(sizeof(ADJNODE));
	new_node->vertex=to;
	new_node->weight=weight;
	new_node->next=NULL;
	if(ptr==NULL){
		g->adjlist[from]=new_node;
	}else{
		while(ptr!=NULL){
			if(ptr->vertex!=from){
				prev=ptr;
				ptr=ptr->next;
			}
		}
		if(prev==NULL){
			g->adjlist[from]=new_node;
		}else{
			prev->next=new_node;
		}
	}
	g->size=g->size+1;
}

/* return the weight of edge (from, to) if exists, otherwise return INFINITY*/
int get_weight(GRAPH *g, int from, int to) {
	ADJNODE *ptr = g->adjlist[from];
	//ADJNODE *prev = NULL;
	int exists = 0;
	if(ptr == NULL)
	{
		return INFINITY;
	}
	else
	{
		while(ptr)
		{
			if(ptr->vertex == to)
			{
				exists = 1;
				break;
			}
			//prev = ptr;
			ptr = ptr->next;
		}
		if(exists == 1)
		{
			return ptr->weight;
		}
		else
			return INFINITY;
	}
}

/* clean the graph by free all dynamically allocated memory*/
void clean_graph(GRAPH **gp) {
	int i;
	ADJNODE* temp, *ptr;
	for(i=0;i<(*gp)->order;i++){
		ptr=(*gp)->adjlist[i];
		while(ptr!=NULL){
			temp=ptr;
			ptr=ptr->next;
			free(temp);
		}
		(*gp)->adjlist[i]=NULL;
	}

}

/* display the graph the proper format*/
void display_graph(GRAPH *g) {
  if (g == NULL) return;
  printf("\nweighted graph in adjacency list");
  printf("\norder: %d", g->order);
  printf("\nsize: %d", g->size);
  printf("\nnode from: (to weight)");
  int i;
  ADJNODE *ptr;
  for (i = 0; i < g->order; i++) {
    printf("\nnode %d:", i);
    ptr = g->adjlist[i];
    while (ptr != NULL) {
      printf(" (%d, %d)", ptr->vertex, ptr->weight);
      ptr = ptr->next;
    }
  }
}



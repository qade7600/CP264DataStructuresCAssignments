Name: Rana Qaderi
ID: 170317600
Email: qade7600@mylaurier.ca
WorkID: cp264a10
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1 
1. new_graph, clean_graph                        [/4/] 
2. add_edge, get_weight                          [/4/]  

Q2 
1. new_edgelist, clean_edglist                   [/4/] 
2. add_edge_start, add_edge_end, weight_edgelist [/4/]

Q3  
1. prim algorithm for MST                        [/5/]
2. shortest path tree by Dijsktra algorithm      [/5/]
3. shortest path by Dijsktra algorithm           [/4/]

Total:                                          [/30/]
 
Q4 (bonus, not required)
1. design of data structure and functions       [/10/]
2. eight puzzle solver algorithm (BFS)          [/10/]

Bonus:                                          [/20/]
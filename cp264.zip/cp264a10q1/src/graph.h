/*
 * graph.h
 *
 *  Created on: 2019 M03 28
 *      Author: ranaqaderi
 */

#ifndef GRAPH_H
#define GRAPH_H

#include <stdio.h>
#include <stdlib.h>

#define INFINITY 99999

typedef struct adjnode  {
    int vertex;
    int weight;
    struct adjnode *next;
} ADJNODE;

typedef struct graph {
    int order;         //number of nodes
    int size;          //number of edges
    ADJNODE **adjlist; //pointer to an array of pointers of neighbors
} GRAPH;

/* create and return a new adjacent list graph of order n */
GRAPH *new_graph(int n);

/* add a new edge (from, to, weight) to the
graph passed by GRAPH *g, if the edge (from, to) exists, update its weight*/
void add_edge(GRAPH *g, int from, int to, int weight);

/* return the weight of edge (from, to) if exists, otherwise return INFINITY*/
int get_weight(GRAPH *g, int from, int to);

/* display the graph the proper format*/
void display_graph(GRAPH *g);

/* clean the graph by free all dynamically allocated memory*/
void clean_graph(GRAPH **gp);

#endif /* GRAPH_H_ */

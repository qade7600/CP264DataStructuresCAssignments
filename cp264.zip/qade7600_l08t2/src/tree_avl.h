/*
 * AVL tree insert and delete operations, using recursive algorithms,
 * adapted from http://www.geeksforgeeks.org/avl-tree-set-2-deletion/
 * HBF
 */
#include<stdio.h>
#include<stdlib.h>

// define AVL tree node
typedef struct node
{
  int key;
  int height;
  struct node *left;
  struct node *right;
} tnode;

tnode *new_node(int key);
void print_preorder(tnode *root);
void print_tree(tnode *root, int prelen);
tnode *insert(tnode *root, int key);
tnode *delete(tnode *root, int key);
tnode *get_smallest_node(tnode* root);
int max(int a, int b);
int height(tnode *root);
tnode *rotate_right(tnode *y);
tnode *rotate_left(tnode *x);
int balance_factor(tnode *n);
int node_count(struct node *root);

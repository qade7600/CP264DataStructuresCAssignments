/*
 ============================================================================
 Project: qade7600_l04t1
 File:    l04t1.c
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include <stdio.h>


int main() {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	char buf[50];
	int count = 0;
	FILE *fp = fopen("data.txt", "r");
	if (fp == NULL){perror("Error opening file"); return 0;}
	else{
		 fgets(buf, sizeof(buf), fp);
		while(!feof(fp)){
			 printf("%s\n", buf);
			 count++;
			 fgets(buf, sizeof(buf), fp);
		 }
		printf("\n");
		printf("There are %d lines in the file", count);

	}
	 fclose(fp);
	 return 0;

}

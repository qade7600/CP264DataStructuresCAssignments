/*
 ============================================================================
 Name        : cp264a1q3.c
 Author      : Rana
 ============================================================================
 */

#include <stdio.h>
#include <math.h>  // need this library for maths functions fabs() and sqrt()

int main()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    float a, b, c, d, x1, x2, x3, x4;
    int inn;
    char temp;

    do {// do-while for new input problem
        // do-while loop to get correct input of three floating numbers,
        do {
            printf("Please enter the coefficients a,b,c:\n");
            inn = scanf("%f,%f,%f", &a,&b,&c);

            if (inn != 3 ) {
               printf("Invalid input\n");
            } else
                break;

              do {  // flush the input buffer
                scanf("%c", &temp);
                if (temp == '\n') break;
              } while (1);

        } while (1);

        if (fabs(a) < 1e-6 && fabs(b) < 1e-6 && fabs(c) < 1e-6) {
            printf("Goodbye\n");
            break;
        }
        else if (fabs(a) < 1e-6) {
            printf("not a quadratic equation\n");
        }
        else {
            d = b * b - 4 * a * c;
            x1 = (-b - (sqrt(d))) / (2 * a * c);
            x2 = (-b + (sqrt(d))) / (2 * a * c);
            x3 = -b / (a * 2);
            x4 = sqrt(-d) / (a * 2);

            // your solution logic

            if (d == 0){
            	printf("The equation has two equal real roots:\n");
                printf("%f \n", x1);
            }
            else if (d < 0){
            	printf("The equation has two complex roots:\n");
            	printf("%f + %fi \n", x3, x4);
            	printf("%f - %fi \n", x3, x4);
            }
            else if (d > 0){
            	printf("The equation has two distinct real roots:\n");
            	printf("%f \n%f \n", x1, x2);
            }

        }

    } while (1);

    return 0;
}





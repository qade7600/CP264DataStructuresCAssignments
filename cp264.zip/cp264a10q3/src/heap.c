#include "heap.h"

HEAP *new_heap(int capacity) {
// your implementation
	HEAP *hp = (HEAP *) malloc(capacity * sizeof(HEAP));
	hp->capacity = capacity;
	hp->size = 0;
	hp->hnap = (HNODE *) malloc(capacity * sizeof(HNODE));
	return hp;
}


void insert(HEAP *heap, HNODE new_node) {
// your implementation
	HEAP *heap_temp = NULL;
	if (heap->size == heap->capacity) {
		heap->capacity <<= 1; // this is to resize by double
		heap_temp = realloc(heap->hnap, sizeof(HNODE) * heap->capacity);
		if (heap_temp) {
			heap->hnap = heap_temp;
		} else {
			heap_temp = malloc(sizeof(HNODE) * heap->capacity);
			if (heap_temp) {
				memcpy(heap_temp, heap->hnap, sizeof(HNODE) * heap->size);
				free(heap->hnap);
				heap->hnap = heap_temp;
			} else {
				printf("array resize failed\n");
			}
		}
	}

	heap->hnap[heap->size] = new_node;
	heap->size += 1;

	int index = heap->size - 1, parent;
	HNODE temp = heap->hnap[index];
	while (index) {
		parent = (index - 1) >> 1;  //equivalent to parent = (index-1)/ 2;
		if (heap->hnap[parent].data >= temp.data)
			break;
		else {
			heap->hnap[index] = heap->hnap[parent];
			index = parent;
		}
	}
	heap->hnap[index] = temp;

}

HNODE extract_min(HEAP *heap) {
// your implementation
	HNODE *hp = (HNODE *) malloc(sizeof(HNODE));
	if (heap->size != 0) {

		*hp = heap->hnap[0];
		heap->size--;
		for (int i = 0; i < heap->size; i++) {
			heap->hnap[i] = heap->hnap[i + 1];
		}

		if (((float) heap->size / (float) heap->capacity) <= 0.25) {
			heap->capacity >>= 1; // this is to resize by half
			heap->hnap = realloc(heap->hnap, sizeof(HNODE) * heap->capacity);
		}
	} else {
		printf("\nNo data\n");
	}


	int index = 0, n = heap->size - 1;
	HNODE temp = heap->hnap[index];
	int ci = (index << 1) + 1;  //left child, equivalent to ci = index * 2 + 1;
	while (ci <= n) { // if has the left child
		if ((ci < n) && (heap->hnap[ci].data < heap->hnap[ci + 1].data))
			ci++;  // ci is now the child of bigger key

		if (heap->hnap[ci].data < temp.data)
			break;   // the both children has key values less the val, done stop.
		else {
			heap->hnap[index] = heap->hnap[ci]; //change key value by the bigger child's value
			index = ci;
			ci = (index << 1) + 1;
		}
	}
	heap->hnap[index] = temp;

	return (*hp);
}

void decrease_key(HEAP *heap, int node_index, KEYTYPE key_value) {
// your implementation
	if (node_index >= 0 && node_index < heap->size)
		heap->hnap[node_index].key = key_value;
	else
		printf("\nIndex out of range\n");

	int index = node_index, parent;
	HNODE temp = heap->hnap[index];
	while (index) {
		parent = (index - 1) >> 1;  //equivalent to parent = (index-1)/ 2;
		if (temp.data >= heap->hnap[parent].data)
			break;
		else {
			heap->hnap[index] = heap->hnap[parent];
			index = parent;
		}
		}
	heap->hnap[index] = temp;
}

int find_index(HEAP *heap, DATA value) {
// your implementation
	int index = 0;
	while (index < heap->size && heap->hnap[index].data != value) {
		index++;
	}
	if (index == heap->size) {
		printf("Data not found");
		return -1;
	} else {
		return index;
	}
}

void display_heap(HEAP *hp) {
	printf("\nsize:%d\ncapacity:%d\n", hp->size, hp->capacity);
	printf("(index, key, data):\n");
	int i;
	for (i = 0; i < hp->size; i++) {
		printf("(%d %d %d) ", i, hp->hnap[i].key, hp->hnap[i].data);
		if (i % 10 == 9)
			printf("\n");
	}
	printf("\n");
}

int cmp(KEYTYPE a, KEYTYPE b) {
	if (a < b)
		return -1;
	else if (a == b)
		return 0;
	else
		return 1;
}

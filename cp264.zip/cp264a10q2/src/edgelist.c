/*
 * edgelist.c
 *
 *  Created on: 2019 M04 1
 *      Author: ranaqaderi
 */

#include"edgelist.h"
#include <stdio.h>
#include <stdlib.h>

/* create and return a new edge list graph*/
EDGELIST *new_edgelist() {
// your implementation
	EDGELIST *new = (EDGELIST*) malloc(sizeof(EDGELIST));
	new->size = 0;
	new->end = NULL;
	new->start = NULL;
	return new;
}

/* add an new edge at the end of the linked list of edges*/
void add_edge_end(EDGELIST *g, int from, int to, int weight) {
// your implementation
	EDGE *new_end = (EDGE*) malloc(sizeof(EDGE));

	new_end->to = to;
	new_end->from = from;
	new_end->weight = weight;

	if (g->end == NULL) {

		g->end = new_end;
		g->start = new_end;
		g->end->next = NULL;

	} else {

		g->end->next = new_end;
		g->end = new_end;
		g->end->next = NULL;

	}

	g->size++;
}

/* add an new edge at the start of the linked list of edges*/
void add_edge_start(EDGELIST *g, int from, int to, int weight) {
// your implementation
	EDGE *new_start = (EDGE*) malloc(sizeof(EDGE));
	new_start->to = to;
	new_start->from = from;
	new_start->weight = weight;

	if (g->start == NULL) {

		g->start = new_start;
		g->end = new_start;
		g->start = NULL;

	} else {
		new_start->next = g->start;
		g->start = new_start;

	}

	g->size++;
}

/* get weight of the edge list graph*/
int weight_edgelist(EDGELIST *g) {
// your implementation
	int total_weight = 0;
	EDGE *ptr = g->start;

	while (ptr) {
		total_weight += ptr->weight;

		ptr = ptr->next;
	}
	return total_weight;
}

/* clean the graph by free all dynamically allocated memory*/
void clean_edgelist(EDGELIST **gp) {
// your implementation
	EDGE *ptr = (*gp)->start, *temp = NULL;

	while (ptr != NULL) {
		temp = ptr;
		ptr = ptr->next;
		free(temp);
	}

	(*gp)->start = NULL;
	(*gp)->end = NULL;
}

/* display edge list graph*/
void display_edgelist(EDGELIST *g) {
	if (g == NULL)
		return;
	printf("\nweighted graph in edge list");
	printf("\nsize: %d", g->size);
	printf("\nformat: (from, to, weight)");
	EDGE *p = g->start;
	while (p) {
		printf("\n(%d, %d, %d)", p->from, p->to, p->weight);
		p = p->next;
	}
}

/*
 * edgelist.h
 *
 *  Created on: 2019 M04 1
 *      Author: ranaqaderi
 */
#include <stdio.h>
#include <stdlib.h>

#ifndef EDGELIST_H_
#define EDGELIST_H_



typedef struct edge {
  int from;
  int to;
  int weight;
  struct edge *next;
} EDGE;

typedef struct edgelist {
  int size;    //number of edges
  EDGE *start; //pointer to the start of edge list
  EDGE *end;   //pointer to end of edge list
} EDGELIST;


/* create and return a new edge list graph*/
EDGELIST *new_edgelist();

/* add an new edge at the end of the linked list of edges*/
void add_edge_end(EDGELIST *g, int from, int to, int weight);

/* add an new edge at the start of the linked list of edges*/
void add_edge_start(EDGELIST *g, int from, int to, int weight);

/* get weight of the edge list graph*/
int weight_edgelist(EDGELIST *g);

/* display edge list graph*/
void display_edgelist(EDGELIST *g);

/* clean the graph by free all dynamically allocated memory*/
void clean_edgelist(EDGELIST **gp);


#endif /* EDGELIST_H_ */

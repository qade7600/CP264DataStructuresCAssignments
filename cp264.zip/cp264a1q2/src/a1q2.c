/*
 ============================================================================
 Name        : cp264a1q2.c
 Author      : Rana
 Version     :
 Copyright   : 
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[])
{
    int i, n = 0, f = 1, prev;

    if ( argc > 1 ) {
    n = atoi( args[1] );  // convert a number string to an integer

    // your program logic
    if (n >= 1){
    	for ( i = 1; i <= n; i++){
    		prev = f;
    		f *= i;

    		if (prev != f/i){
    			printf("Overflow at %d!\n", i);
    			break;
    		}
    		printf("%11d", f);
    		if (i % 4 == 0) printf("\n");


    	}
    }else {
    	printf("invalid argument\n");
    }

    }
    else
        printf("no argument");

    return 0;
}

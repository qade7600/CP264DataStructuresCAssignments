/*
 ============================================================================
 Name        : qade7600_l10t1.c
 Author      : Rana
 Version     :
 Copyright   : 
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "graph_am.h"


int main() {
  int adj[MAX][MAX];
  int visited[MAX];
  int i;

  randomGraph(adj);
  displayAdjacentMatrix(adj);

  printf("\nBFS:\n");
  for (i=0; i<MAX; i++) visited[i] = 0;
  breadth_first_search(adj, visited, 0);

  printf("\nDFS:\n");
  for (i=0; i<MAX; i++) visited[i] = 0;
  depth_first_search(adj,visited,0);

  printf("\nDFS recursion:\n");
  for (i=0; i<MAX; i++) visited[i] = 0;
  depth_first_search_recursive(adj,visited,0);
  return 0;
}

/*
   0 1 2 3 4 5 6 7 8 9
0  0 0 1 1 0 1 0 0 0 0
1  0 0 0 1 1 0 1 1 1 0
2  1 0 0 1 0 1 0 1 0 1
3  1 1 1 0 0 0 1 0 1 0
4  0 1 0 0 0 1 0 0 1 1
5  1 0 1 0 1 0 1 0 0 0
6  0 1 0 1 0 1 0 1 1 1
7  0 1 1 0 0 0 1 0 1 0
8  0 1 0 1 1 0 1 1 0 1
9  0 0 1 0 1 0 1 0 1 0

BFS:
0 2 3 5 7 9 1 6 8 4
DFS:
0 2 3 1 4 5 6 7 8 9
DFS recursion:
0 2 3 1 4 5 6 7 8 9
 */

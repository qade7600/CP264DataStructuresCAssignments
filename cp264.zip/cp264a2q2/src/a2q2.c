/*
 ============================================================================
 Project: cp264a2q2
 File:    a2q2.c
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */
#include<stdio.h>
#include<stdlib.h>
#include <math.h>


float horner(float x, int n, float a[]) {
	// your implementation
	int i;
	float result = 0;
	for (i = 0; i <= n; i++) {
		result = result + (a[i] * pow(x, n - i));
		}
	return result;
}



int main(int argc, char* args[]) {
	//get polynomial efficients from command line arguments

	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	if (argc <= 1) {
		printf("Need more than one arguments, e.g.: 1 2 3 4\n");
		return 0;
	}
	int i, n = argc - 1;
	float a[n];
	// declare float array data structure for coefficients
	// read command line arguments convert them to floating numbers atof(args[i+1]);
	for (i = 1; i <= n; i++) {
		a[i] = atof(args[i]);
	}
	// repetitive polynomial evaluation for user input of x value
	float x = 0.0;
	do {
		//get x value from keyboard
		do {
			printf("Please enter x value (Ctrl+C or 999 to quit):\n");
			if (scanf("%f", &x) != 1) {
				printf("Invalid input\n");
			} else {
				break;
			}

			// handle invalid input
			// while(getchar() !='\n') ;
			do {
				if (getchar() == '\n')
					break;
			} while (1);

		} while (1);

		if (x == 999) {
			break;
		}

		for (i = 1; i <= n; i++) {
			if (i == n) {
				printf("%.1f*%.1f^%d= ", a[i], x, n - i);
			} else {
				printf("%.1f*%.1f^%d + ", a[i], x, n - i);
			}
		}
		printf("%.1f\n", horner(x, n, a));



		// escape when input 999
		// print the polynomial expression
		// use x^n to denote x raised to the n-th power
		// use %.1f format for floating number
		// print polynomial by calling horner(x, n, a)

	} while (1);

	return 0;
}

/*
 ============================================================================
 Project: qade7600_l07t3
 File:    l07t3
 -------------------------------------------------------
 Author:  Rana Qaderi
 Version: 2019-01-11
 ============================================================================
 */

#include "simple_bst.h"

int main() {
	tnode *root = NULL, *np;
	printf("\nTest BST recursive algorithm\n");
	recursive_insert(&root, 5);
	recursive_insert(&root, 7);
	recursive_insert(&root, 2);
	recursive_insert(&root, 4);
	recursive_insert(&root, 3);
	recursive_insert(&root, 6);
	recursive_insert(&root, 9);
	recursive_insert(&root, 1);
	recursive_insert(&root, 8);

	printf("\n");
	print_tree(root, 0);

	printf("\nleaf count: %d", leaf_count(root));


	printf("\ntree height: %d",tree_height(root));

	printf("\nin-order: ");
	print_inorder(root);

	printf("\npre-order: ");
	print_preorder(root);

	printf("\npos-torder: ");
	print_postorder(root);

	np = recursive_search(root, 7);
	if (np)
		printf("\nFound %d by recursive search", np->data);
	else
		printf("\nNot found");

	np = recursive_search(root, 10);
	if (np)
		printf("\nFound %d by recursive search", np->data);
	else
		printf("\nNot found");

	printf("\nSmallest element: %d\n", find_smallest_element(root)->data);
	printf("\nLargestest element: %d\n",
			iterative_find_largest_element(root)->data);

	print_tree(root, 0);
	printf("\nDelete %d\n", 7);
	recursive_delete(&root, 7);
	print_tree(root, 0);
	printf("Delete %d\n", 3);
	recursive_delete(&root, 3);
	print_tree(root, 0);
	printf("Delete %d\n", 5);
	recursive_delete(&root, 5);
	print_tree(root, 0);
	clean_tree(&root);

	printf("\niterative insert algorithm\n");
	iterative_insert(&root, 5);
	iterative_insert(&root, 7);
	iterative_insert(&root, 2);
	iterative_insert(&root, 4);
	iterative_insert(&root, 3);
	iterative_insert(&root, 6);
	iterative_insert(&root, 9);
	iterative_insert(&root, 1);
	iterative_insert(&root, 8);

	printf("\ntree style\n");
	print_tree(root, 0);

	printf("\niterative search algorithm\n");
	np = iterative_search(root, 7);
	if (np)
		printf("\nFound %d by iterative search", np->data);
	else
		printf("\nNot found");

	np = iterative_search(root, 10);
	if (np)
		printf("\nFound %d by iterative search", np->data);
	else
		printf("\nNot found");

	printf("\niterative delete algorithm without extracting\n");
	print_tree(root, 0);
	printf("\nDelete %d\n", 7);
	iterative_delete(&root, 7);
	print_tree(root, 0);
	printf("Delete %d\n", 3);
	iterative_delete(&root, 3);
	print_tree(root, 0);
	printf("Delete %d\n", 5);
	iterative_delete(&root, 5);
	print_tree(root, 0);
	clean_tree(&root);

	printf("\niterative extrace and delete algorithm\n");
	iterative_insert(&root, 5);
	iterative_insert(&root, 7);
	iterative_insert(&root, 2);
	iterative_insert(&root, 4);
	iterative_insert(&root, 3);
	iterative_insert(&root, 6);
	iterative_insert(&root, 9);
	iterative_insert(&root, 1);
	iterative_insert(&root, 8);
	print_tree(root, 0);

	printf("delete 5:");
	iterative_delete_extract(&root, 5);
	printf("\n");
	print_tree(root, 0);

	printf("delete 3:");
	iterative_delete_extract(&root, 3);
	printf("\n");
	print_tree(root, 0);

	printf("delete 6:");
	iterative_delete_extract(&root, 6);
	printf("\n");
	print_tree(root, 0);

	printf("delete 9:");
	iterative_delete_extract(&root, 9);
	printf("\n");
	print_tree(root, 0);

	clean_tree(&root);

	return 0;
}

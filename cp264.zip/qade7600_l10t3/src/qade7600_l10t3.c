/*
 ============================================================================
 Name        : qade7600_l10t3.c
 Author      : Rana
 Version     :
 Copyright   : 
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "graph_a1.h"

int main(int argc, char *args[]) {
  int n = 10;
  if (argc >1) n = atoi(args[1]);

    //declear adjacent list
  node *adj[n];
  //initialization graph
  int i;
  for (i = 0; i < n; i++) adj[i] = NULL;

  for (i = 0; i < n-1; i++) {
     add_edge(adj, n, i, i+1);
  }
  add_edge(adj, n, n-1, 0);
  printf("\nDisplay Graph:");
  display_graph(adj, n);
  printf("\nReach count: %d\n", reach_count(adj, n, 0));

  for (i = 0; i < n-1; i++) {
     if (i%2 == 0)
     delete_edge(adj, n, i, i+1);
  }
  printf("\nDisplay Graph:");
  display_graph(adj, n);
  printf("\nReach count: %d\n", reach_count(adj, n, 0));

  delete_graph(adj, n);

  //generate random graph
  random_graph(adj, n);

  //bidirect_graph(adj, n);
  printf("\nDisplay Graph:");
  display_graph(adj, n);

  //declear visited array to be used by DFS and BFS
  int visited[n];
  //initialization of visited array
  for (i=0; i<n; i++) visited[i] = 0;
  printf("\nBFS order:\n");
  //BFS start from 0
  breadth_first_search(adj, n, visited, 0);
  printf("\nvisited by BFS:\n");
  for (i=0; i<n; i++) {
    if (visited[i] == 1) printf("%d ", i);
  }

  //initialization of visited array
  for (i = 0; i < n; i++) visited[i] = 0;
  printf("\nDFS recursive order:\n");
  //DFS start from 0
  depth_first_search_recursive(adj, n, visited, 0);
  printf("\nvisited by DFS:\n");
  for (i=0; i<n; i++) {
     if (visited[i] == 1) printf("%d ", i);
  }

  //initialization of visited array
  for (i = 0; i < n; i++) visited[i] = 0;
  printf("\nDFS iterative order:\n");
  //DFS start from 0
  depth_first_search_iterative(adj, n, visited, 0);
    printf("\nvisited by DFS:\n");
  for (i=0; i<n; i++) {
     if (visited[i] == 1) printf("%d ", i);
  }

  printf("\nReach count: %d\n", reach_count(adj, n, 0));
  delete_graph(adj, n);
  return 0;
}

/*
Display Graph:
node 0 neighbors: 1
node 1 neighbors: 2
node 2 neighbors: 3
node 3 neighbors: 4
node 4 neighbors: 5
node 5 neighbors: 6
node 6 neighbors: 7
node 7 neighbors: 8
node 8 neighbors: 9
node 9 neighbors: 0
Reach count: 10

Display Graph:
node 0 neighbors:
node 1 neighbors: 2
node 2 neighbors:
node 3 neighbors: 4
node 4 neighbors:
node 5 neighbors: 6
node 6 neighbors:
node 7 neighbors: 8
node 8 neighbors:
node 9 neighbors: 0
Reach count: 1

Graph is deleted
Display Graph:
node 0 neighbors: 9 4
node 1 neighbors: 3 6 2 9 5 4 7 0
node 2 neighbors: 9 5 3 7 8 6 0 4 1
node 3 neighbors: 4 2
node 4 neighbors: 7 0 9 5 1 6 8 3 2
node 5 neighbors: 8 4
node 6 neighbors: 0 1 3 9 4 5 7 2
node 7 neighbors: 0 1 2 9 4 6
node 8 neighbors: 7 1 9 4 3
node 9 neighbors: 6 3 1
BFS order:
0 9 4 6 3 1 7 5 8 2
visited by BFS:
0 1 2 3 4 5 6 7 8 9
DFS recursive order:
0 9 6 1 3 4 7 2 5 8
visited by DFS:
0 1 2 3 4 5 6 7 8 9
DFS iterative order:
0 4 2 3 8 6 1 5 7 9
visited by DFS:
0 1 2 3 4 5 6 7 8 9
Reach count: 10

Graph is deleted
 */


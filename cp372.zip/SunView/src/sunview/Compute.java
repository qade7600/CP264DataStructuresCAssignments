package sunview;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Compute {
	
	public static ArrayList<SolarP> readPanels(Scanner sc){
		
		ArrayList<SolarP> panels = new ArrayList<SolarP>();
			
		String line = sc.nextLine();
		String[] bs;
		double[] ba = new double[] {0,0,0,0,0};
		
		while (line != null) {
			bs = line.split(",");
			
			for (int i=0; i<5; i++) {
				ba[i] = Double.parseDouble(bs[i]);
			}
			
			SolarP q = new SolarP(ba[0], ba[2], ba[1], ba[3], ba[4], ba[0]/ba[2]);
			panels.add(q);
			
			if(sc.hasNextLine()) {
				line = sc.nextLine();
			}
			else {
				break;
			}
		}
			
		return panels;
	}
	
	public static double avgTemp(ArrayList<SolarP> panels) {
		double avgTemp = 0;
		int count = 0;
		double totTemp = 0;
		
		for (SolarP m : panels) {
			totTemp += m.getTemp();
			count += 1;
		}
		
		avgTemp = totTemp / count;
		return avgTemp;
	}
	
	public static double avgEfficiency(ArrayList<SolarP> panels) {
		double avgEfficiency = 0;
		int count = 0;
		double totEfficiency = 0;
		
		for (SolarP m : panels) {
			totEfficiency += m.getEfficiency();
			count += 1;
		}
		
		avgEfficiency = totEfficiency / count;
		return avgEfficiency;
	}
	
	public static double avgWind(ArrayList<SolarP> panels) {
		double avgWind = 0;
		int count = 0;
		double totWind = 0;
		
		for (SolarP m : panels) {
			totWind += m.getWind();
			count += 1;
		}
		
		avgWind = totWind / count;
		return avgWind;
	}
	
	public static double totalpower(ArrayList<SolarP> panels) {
		double total_power = 0;
		
		for(SolarP m : panels) {
			total_power += m.getPower();
		}
		
		return total_power;
		
	}
	
	public static double[] carbonemissions_saved(double power) {

		double emissions[] = new double[3];

		double carbon_natural_gas = 0.572;
		double carbon_solar = 0.02;
		double carbon_coal = 1.142;

		double carbon_emissions_coal = carbon_coal * power;
		double carbon_emissions_naturalgas = carbon_natural_gas * power;
		double carbon_emissions_solar = carbon_solar * power;

		emissions[0] = carbon_emissions_coal - carbon_emissions_solar;
		emissions[1] = carbon_emissions_naturalgas - carbon_emissions_solar;
		emissions[2] = carbon_emissions_solar;

		return emissions;

	}

	
	public static void main(String[] args) throws FileNotFoundException {
		File f = new File("solardata.csv");
		Scanner sc = new Scanner(f);
		
		ArrayList<SolarP> panels = new ArrayList<SolarP>();
		panels = readPanels(sc);
		sc.close();
		
		System.out.println(panels.get(0));
		System.out.println(panels.get(0).getPower());
		System.out.println(totalpower(panels));
		System.out.println(avgWind(panels));
		System.out.printf("%.2f\n", avgTemp(panels));
		System.out.println(avgEfficiency(panels));
	}
	}

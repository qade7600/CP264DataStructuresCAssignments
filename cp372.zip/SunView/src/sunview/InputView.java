package sunview;

import java.awt.BorderLayout;
import java.awt.Color;

import sunview.Compute;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import org.jfree.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.function.*;
import javax.swing.BoxLayout;
import javax.swing.border.TitledBorder;


@SuppressWarnings("serial")
public class InputView extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InputView frame = new InputView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InputView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
		
		JPanel BarGraph = new JPanel();
		BarGraph.setToolTipText("Report");
		BarGraph.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(BarGraph);
		
		JButton btnCarbonEmissions = new JButton("Carbon emissions");
		BarGraph.add(btnCarbonEmissions);
		btnCarbonEmissions.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultCategoryDataset dcd= new DefaultCategoryDataset();
				
				File f = new File("solardata.csv");
				Scanner sc = null;
				try {
					sc = new Scanner(f);
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ArrayList<SolarP> panels = Compute.readPanels(sc);
				
			
				double[] list= Compute.carbonemissions_saved(Compute.totalpower(panels));
				dcd.setValue(list[0], "coal", "carbon emissions saved from coal");
				dcd.setValue(list[1], "natural gas", "carbon emissions saved from natural gas");
				dcd.setValue(list[2], "solar power", "carbon emissions from solar power");

				
				
	
				JFreeChart jchart= ChartFactory.createBarChart("Carbon Emissions", "Energy type", "carbon emissions per KWh", dcd);
				CategoryPlot plot= jchart.getCategoryPlot();
				plot.setRangeGridlinePaint(Color.black);
				
				ChartFrame chartFrm= new ChartFrame("Student Record",jchart,true);
				
				chartFrm.setVisible(true);
				chartFrm.setSize(500,400);
				ChartPanel chartPanel= new ChartPanel(jchart);
				BarGraph.removeAll();
				
				BarGraph.add(chartPanel);
				BarGraph.updateUI();
				
			}
		});
	}
}

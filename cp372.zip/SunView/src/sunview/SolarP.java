package sunview;

public class SolarP {
	
	private double power = 0;
	private double epower = 0;
	private double temp = 0;
	private double wind = 0;
	private double force = 0;
	private double efficiency = 0;
	
	public double getEfficiency() {
		return efficiency;
	}

	public SolarP(double power, double epower, double temp, double wind, double force, double efficiency) {
		this.power = power;
		this.epower = epower;
		this.temp = temp;
		this.wind = wind;
		this.force = force;
		this.efficiency = efficiency;
	}	

	public double getPower() {
		return power;
	}



	public double getEpower() {
		return epower;
	}



	public double getTemp() {
		return temp;
	}



	public double getWind() {
		return wind;
	}



	public double getForce() {
		return force;
	}



	public static void main(String[] args) {
		SolarP p = new SolarP(1.25, 1.35, 25, 15, 17, 0.80);
		System.out.println(p.getEfficiency());
	}
}
